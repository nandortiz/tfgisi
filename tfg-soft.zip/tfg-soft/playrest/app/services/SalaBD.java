package services;

import entities.*;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SalaBD extends ConexionBD {

    private static SalaBD instance;
    public static SalaBD getInstance() {
        if (instance == null) {
            instance = new SalaBD();
        }
        return instance;
    }


    public Sala addSala(Sala sala, int bibliotecaID) throws SQLException, ClassNotFoundException {
        int identificador= -1;
        if (conector() == true) {
            con.setAutoCommit(false);
            try {


                String descripcion = sala.getDescripcionSala();
                ArrayList<LocalDateTime> disponibilidadSala = new ArrayList<>();
                disponibilidadSala= sala.getListaDisponibilidadSala();

                System.out.println("El identificador de la biblioteca es: " + bibliotecaID);
                createStatement.executeUpdate("INSERT INTO sala (descripcion,bibliotecaID) VALUES ('" + descripcion + "', " + bibliotecaID+");",Statement.RETURN_GENERATED_KEYS);
                ResultSet prueba = createStatement.getGeneratedKeys();
                prueba.next();
                identificador=prueba.getInt(1);
                System.out.println("la fila es " + identificador );
                String patron = "/bibliotecas/" + bibliotecaID + "/salas/";
                String url = patron+identificador;
                createStatement.executeUpdate("UPDATE  sala set url ='" + url + "' where id = "+ identificador + ";");

                for (LocalDateTime dispo:disponibilidadSala) {

                    createStatement.executeUpdate("INSERT INTO disponibilidadsala (salaid,disponibilidad) VALUES (" + identificador + ", '" + dispo +  "');");
                }
                con.commit();
                con.setAutoCommit(true);
                con.close();
            }
            catch(SQLException e){
                con.rollback();
            }

        }
        // return sala;
        return getSala(bibliotecaID,identificador);
    }

    public Sala getSala(int bibliotecaID, int id) {

        HashMap<Integer,Sala> mapa = new HashMap<>();
        try {
            if(conector()==true){

                String queryBD = "select sala.id, sala.url, sala.descripcionSala, sala.bibliotecaid, disponibilidadsala.disponibilidad  from sala inner join disponibilidadsala on sala.id = disponibilidadsala.salaid where sala.id =" + id + " AND sala.bibliotecaid =" + bibliotecaID +" ;";
                String queryBD1="select sala.id, sala.url, sala.descripcionSala, sala.bibliotecaid , recursosala.id as recursoSalaID , recursosala.url as recursoSalaURL, recursosala.nombre as recursoSalaNombre, recursosala.descripcion as recursoSalaDescripcion, recursosala.bibliotecaid as recursoBibliotecaID, recursosala.salaid as recursoSalaID from sala INNER JOIN recursosala on sala.id = recursosala.salaid  where sala.id =" + id + " AND sala.bibliotecaid =" + bibliotecaID +" ;";
                int i=0;

                try {

                    rS = createStatement.executeQuery(queryBD);
                } catch (SQLException ex) {
                    Logger.getLogger(SalaBD.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (rS == null){
                    return null;

                }
                else{

                    try {
                        while (rS.next()) {
                            Sala sala;

                            if (mapa.containsKey(Integer.parseInt(rS.getString("sala.id")))){
                                sala=mapa.get(Integer.parseInt(rS.getString("sala.id")));

                            }
                            else{

                                sala = new Sala();
                                sala.setId(Integer.parseInt(rS.getString("sala.id")));
                                sala.setUrl(rS.getString("sala.url"));
                                sala.setDescripcionSala(rS.getString("sala.descripcionSala"));
                                sala.setBibliotecaID(Integer.parseInt(rS.getString("sala.bibliotecaid")));

                                mapa.put(sala.getId(), sala);
                            }


                            LocalDateTime tiempo = rS.getObject("disponibilidadsala.disponibilidad",LocalDateTime.class);

                            sala.annadirListaDisponibilidadSala(tiempo);





                        }
                        rS1= createStatement.executeQuery(queryBD1);
                        while (rS1.next()) {
                            Sala sala=null;
                            if (mapa.containsKey(Integer.parseInt(rS1.getString("sala.id")))){
                                sala=mapa.get(Integer.parseInt(rS1.getString("sala.id")));

                            }

                            RecursoSalaShort recursoSala = new RecursoSalaShort();

                            recursoSala.setId(Integer.parseInt(rS1.getString("recursoSalaID")));
                            recursoSala.setUrl(rS1.getString("recursoSalaURL"));
                            recursoSala.setNombreRecursoSala(rS1.getString("recursoSalaNombre"));
                            recursoSala.setDescripcionRecursoSala(rS1.getString("recursoSalaDescripcion"));
                            recursoSala.setBibliotecaID(Integer.parseInt(rS1.getString("recursobibliotecaID")));
                            recursoSala.setSalaID(Integer.parseInt(rS1.getString("recursoSalaID")));

                            sala.annadirListaRecursoSala(recursoSala);
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(SalaBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    try {
                        i = 0;
                        con.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(SalaBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            }
            else{
                return null;

            }
        } catch (SQLException ex) {
            Logger.getLogger(SalaBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SalaBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (mapa.values().size() >0){


            return new ArrayList<>(mapa.values()).get(0);

        }
        else {
            return null;
        }


    }

    public Collection<SalaShort> getAllSalas(int bibliotecaID) {

        HashMap<Integer,SalaShort> mapa = new HashMap<>();

        try {
            if(conector()==true){
                String queryBD = "select id, url, descripcionSala, bibliotecaid  from sala where bibliotecaid =" + bibliotecaID + " ;";
                int i=0;
                try {
                    rS = createStatement.executeQuery(queryBD);

                    while (rS.next()) {

                        SalaShort sala;

                        if (mapa.containsKey(Integer.parseInt(rS.getString("id")))){
                            sala=mapa.get(Integer.parseInt(rS.getString("id")));
                        }
                        else{
                            sala = new SalaShort();
                            sala.setId(Integer.parseInt(rS.getString("id")));
                            sala.setUrl(rS.getString("url"));
                            sala.setDescripcionSala(rS.getString("descripcionSala"));
                            sala.setBibliotecaID(Integer.parseInt(rS.getString("bibliotecaid")));
                            mapa.put(sala.getId(), sala);
                        }

                    }
                } catch (SQLException ex) {
                    Logger.getLogger(SalaBD.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    i=0;
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(SalaBD.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
            else{
                //return new ArrayList<>(mapa.values);
                return null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(SalaBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SalaBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        //System.out.println("El tamaño de la lista es" + mapa.values().size());
        return mapa.values();

    }

    public Sala updateSala(Sala sala,int bibliotecaID, int id) throws SQLException, ClassNotFoundException {
        try {
            if (conector() == true) {
                // int id = sala.getId();
                //String url = sala.getUrl();

                String descripcion= sala.getDescripcionSala();

                String queryBD = "update sala set descripcionSala='"+descripcion+"' where id="+id+" AND bibliotecaid= " + bibliotecaID + ";";

                try {
                    createStatement.executeUpdate(queryBD);
                } catch (SQLException ex) {
                    Logger.getLogger(SalaBD.class.getName()).log(Level.SEVERE, null, ex);
                }

                try {

                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(SalaBD.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else{

            }
        } catch (SQLException ex) {
            Logger.getLogger(SalaBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SalaBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return getSala(bibliotecaID, id);
    }
    public CambioHorario cambioSala(CambioHorario cam, int bibliotecaID, int id) throws SQLException, ClassNotFoundException {
        try {
            if (conector() == true) {
                switch (cam.getTipo()) {

                    case ADD:
                        //insert tabla disponibilidadSala con el id y la franja
                        LocalDateTime franja = cam.getFranja();
                        createStatement.executeUpdate("INSERT INTO disponibilidadsala (salaid,disponibilidad) VALUES (" + id + ", '" + franja + "');");
                        break;

                    case REMOVE:
                        //delete tabla disponibilidadBiblioteca con el id y la franja
                        LocalDateTime franjaRemove = cam.getFranja();
                        createStatement.executeUpdate("delete from disponibilidadsala where salaid="+id+" AND disponibilidad='" + franjaRemove+ "';");
                        break;


                }

            }
        } catch (SQLException ex) {
            Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
        }

        return cam;
    }

    public boolean deleteSala(int bibliotecaID,int id) throws SQLException, ClassNotFoundException {
        boolean valor= false;
        try {
            if (conector() == true) {

                String queryBD = "delete from sala where id="+id+" AND bibliotecaid= " + bibliotecaID + ";";

                try {
                    createStatement.executeUpdate(queryBD);
                    valor = true;
                    return valor;
                } catch (SQLException ex) {
                    Logger.getLogger(SalaBD.class.getName()).log(Level.SEVERE, null, ex);
                }

                try {

                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(SalaBD.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else{

            }
        } catch (SQLException ex) {
            Logger.getLogger(SalaBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SalaBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return valor;
    }

}
