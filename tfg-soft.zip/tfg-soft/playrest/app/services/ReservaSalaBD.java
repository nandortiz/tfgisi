package services;

import entities.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ReservaSalaBD extends ConexionBD{

    private static ReservaSalaBD instance;
    public static ReservaSalaBD getInstance() {
        if (instance == null) {
            instance = new ReservaSalaBD();
        }
        return instance;
    }

    public ReservaSala addReservaSala(ReservaSala reservasala) throws SQLException, ClassNotFoundException {
        int usID=0;  int bibliotecaID =0; int salaID=0;
        int identificador= -1; int numberRow=-1;int numberRowLab= -1; int contadorRecursoSala=0;
        if (conector() == true) {
            con.setAutoCommit(false);
            try {

                Usuario us = reservasala.getUs();
                BibliotecaShort biblioteca= reservasala.getBiblioteca();
                SalaShort sal =  reservasala.getSala();
                usID= us.getId();
                System.out.println("El ID del Usuario es el siguiente" +usID);
                bibliotecaID= biblioteca.getId();
                System.out.println("El ID de la Biblioteca es el siguiente" +bibliotecaID);
                salaID= sal.getId();
                System.out.println("El ID del Puesto es el siguiente" + salaID);

                LocalDateTime horario= reservasala.getDisponibilidadReserva();
                System.out.println("El horario de la reserva es el siguiente" +horario);


                ArrayList<RecursoSalaShort> recursoSala= new ArrayList<>();
                System.out.println("El tamaño de la lista de recursoSala es: " + recursoSala.size());
                recursoSala = reservasala.getListaRecursoSala();
                System.out.println("El tamaño de la lista de recursoSala es: " + recursoSala.size());

                String queryBD1=("select count(*) from usuario where id="+ usID +";");
                String queryBD2=("select count(*) from disponibilidadbiblioteca where bibliotecaID="+ bibliotecaID +" AND disponibilidad = '"+ horario + "';");
                String queryBD3=("delete from disponibilidadsala where salaid="+ salaID +" AND disponibilidad = '"+ horario + "';");

                rS=createStatement.executeQuery(queryBD1);
                while (rS.next()){
                    numberRow =rS.getInt("count(*)");
                }
                if(numberRow==1){
                    System.out.println("El usuario está bien");
                    rS=createStatement.executeQuery(queryBD2);
                    while (rS.next()){
                        numberRowLab =rS.getInt("count(*)");
                    }
                    if(numberRowLab==1){
                        System.out.println("La biblioteca está bien");
                        createStatement.executeUpdate(queryBD3);
                        if(createStatement.getUpdateCount()==1){
                            System.out.println("La sala está bien");
                            for (RecursoSalaShort rs:recursoSala) {
                                int recursoID= rs.getId();
                                System.out.println("El tamaño de la lista de recursosSala es: " + recursoSala.size());
                                System.out.println("El ID del recurso es el siguiente " + recursoID );
                                createStatement.executeUpdate("delete from disponibilidadrecursosala where recursosalaid="+ recursoID +" AND disponibilidad = '"+ horario + "';");
                                if(createStatement.getUpdateCount()==1){
                                    contadorRecursoSala++;
                                }
                                System.out.println("el tamaño del contador es " + contadorRecursoSala);
                            }
                            if(contadorRecursoSala==recursoSala.size()){



                                createStatement.executeUpdate("INSERT INTO reservasala (usuarioid,bibliotecaid,salaid, disponibilidad) VALUES (" + usID + ", " + bibliotecaID+ ", "  + salaID+" ,'" + horario+ "' );", Statement.RETURN_GENERATED_KEYS);
                                ResultSet prueba = createStatement.getGeneratedKeys();
                                prueba.next();
                                identificador=prueba.getInt(1);
                                System.out.println("la fila es " + identificador );
                                String url = "/reservasSalas/"+identificador;
                                createStatement.executeUpdate("UPDATE  reservasala set url ='" + url + "' where id = "+ identificador + ";");

                                for (RecursoSalaShort recursosala:recursoSala) {
                                    int recursoSalaID= recursosala.getId();
                                    createStatement.executeUpdate("INSERT INTO reservarecursosala (reservaSalaId,recursoSalaId) VALUES (" + identificador + ", " + recursoSalaID +  ");");
                                }

                                con.commit();
                                con.setAutoCommit(true);
                                con.close();




                            }
                            else {
                                reservasala=null;
                                System.out.println("Algún recurso de la sala en grupo o la disponibilidad que busca no existe");
                                con.rollback();
                            }

                        }
                        else {
                            reservasala = null;
                            System.out.println("La sala o la disponibilidad que busca no existe");
                            con.rollback();
                        }
                    }
                    else {
                        reservasala=null;
                        System.out.println("La biblioteca a la que quiere acudir o la disponibilidad que busca no existe");
                        con.rollback();
                    }

                }
                else {

                    reservasala=null;
                    System.out.println("El usuario que busca no existe");
                    con.rollback();
                }





            }

            catch(SQLException e){
                e.printStackTrace();
                con.rollback();
            }

        }
        //return reservasala;
        return getReservaSala(identificador);
    }

    public ReservaSala getReservaSala(int id) {
        int usuarioID = 0; int bibliotecaID=0; int salaID=0; int recursoSalaID=0;
        String usuarioURL; String bibliotecaURL; String salaURL; String recursoSalaURL;

        HashMap<Integer,ReservaSala> mapa = new HashMap<>();
        try {
            if(conector()==true){
                String queryBD= "select reservasala.id, reservasala.url, reservasala.usuarioid , reservasala.bibliotecaid, reservasala.salaid,reservasala.disponibilidad, reservarecursosala.recursosalaid as recursoSalaID, usuario.url as usuarioURL, biblioteca.url as bibliotecaURL, sala.url as salaURL, recursosala.url as recursoSalaURL from reservasala inner join reservarecursosala on reservasala.id = reservarecursosala.reservasalaid inner join usuario on reservasala.usuarioid  =usuario.id inner join biblioteca on reservasala.bibliotecaID =biblioteca.id inner join sala on reservasala.salaid =sala.id inner join recursosala on reservarecursosala.recursosalaid =recursosala.id where reservasala.id =" + id+" ;";
                int i=0;

                try {

                    rS = createStatement.executeQuery(queryBD);

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    Logger.getLogger(ReservaSalaBD.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (rS == null){
                    //sala= null;

                }
                else{

                    try {

                        while (rS.next()) {

                            ReservaSala reservasala;

                            if (mapa.containsKey(Integer.parseInt(rS.getString("reservasala.id")))){

                                reservasala=mapa.get(Integer.parseInt(rS.getString("reservasala.id")));

                            }
                            else{
                                System.out.println("Nueva Reservas ");
                                reservasala = new ReservaSala();
                                Usuario us = new Usuario();
                                BibliotecaShort biblioteca= new BibliotecaShort();
                                SalaShort sala =new SalaShort();

                                reservasala.setId(Integer.parseInt(rS.getString("reservasala.id")));
                                reservasala.setUrl(rS.getString("reservasala.url"));
                                usuarioID=Integer.parseInt(rS.getString("reservasala.usuarioid"));
                                us.setId(usuarioID);
                                usuarioURL=rS.getString("usuarioURL");
                                us.setUrl(usuarioURL);
                                reservasala.setUs(us);

                                bibliotecaID=Integer.parseInt(rS.getString("reservasala.bibliotecaid"));
                                biblioteca.setId(bibliotecaID);
                                bibliotecaURL=rS.getString("bibliotecaURL");
                                biblioteca.setUrl(bibliotecaURL);
                                reservasala.setBiblioteca(biblioteca);
                                salaID=Integer.parseInt(rS.getString("reservabiblioteca.salaid"));
                                sala.setId(salaID);
                                salaURL=rS.getString("salaURL");
                                sala.setUrl(salaURL);
                                reservasala.setSala(sala);
                                LocalDateTime horario=rS.getObject("reservasala.disponibilidad",LocalDateTime.class);
                                reservasala.setDisponibilidadReserva(horario);


                                mapa.put(reservasala.getId(), reservasala);
                            }



                            RecursoSalaShort recursoSala = new RecursoSalaShort();
                            recursoSala.setId(Integer.parseInt(rS.getString("recursoSalaID")));
                            recursoSala.setUrl(rS.getString("recursoSalaURL"));


                            reservasala.annadirListaRecursoSala(recursoSala);






                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        Logger.getLogger(ReservaSalaBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    try {
                        i = 0;
                        con.close();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        Logger.getLogger(ReservaSalaBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            }
            else{
                //reservaSala=null;


            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            Logger.getLogger(ReservaSalaBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
            Logger.getLogger(ReservaSalaBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (mapa.values().size() >0){



            return new ArrayList<>(mapa.values()).get(0);

        }
        else {

            return null;

        }


    }

    public Collection<ReservaSala> getAllReservaSala() {
        int usuarioID = 0; int bibliotecaID=0; int salaID=0; int recursoSalaID=0;


        HashMap<Integer,ReservaSala> mapa = new HashMap<>();
        try {
            if(conector()==true){

                String queryBD= "select reservasala.id, reservasala.url, reservasala.usuarioid , reservasala.bibliotecaid, reservasala.salaid,reservasala.disponibilidad, reservarecursosala.recursosalaid as recursoSalaID from reservasala inner join reservarecursosala on reservasala.id = reservarecursosala.reservasalaid ;";
                int i=0;

                try {

                    rS = createStatement.executeQuery(queryBD);
                } catch (SQLException ex) {
                    Logger.getLogger(ReservaSalaBD.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (rS == null){
                    //sala= null;

                }
                else{

                    try {
                        while (rS.next()) {
                            ReservaSala reservasala;

                            if (mapa.containsKey(Integer.parseInt(rS.getString("reservasala.id")))){
                                reservasala=mapa.get(Integer.parseInt(rS.getString("reservasala.id")));

                            }
                            else{

                                reservasala = new ReservaSala();
                                Usuario us = new Usuario();
                                BibliotecaShort biblioteca= new BibliotecaShort();
                                SalaShort sala =new SalaShort();

                                reservasala.setId(Integer.parseInt(rS.getString("reservasala.id")));
                                reservasala.setUrl(rS.getString("reservasala.url"));
                                usuarioID=Integer.parseInt(rS.getString("reservasala.usuarioid"));
                                us.setId(usuarioID);
                                reservasala.setUs(us);

                                bibliotecaID=Integer.parseInt(rS.getString("reservasala.bibliotecaid"));
                                biblioteca.setId(bibliotecaID);
                                reservasala.setBiblioteca(biblioteca);
                                salaID=Integer.parseInt(rS.getString("reservasala.salaid"));
                                sala.setId(salaID);
                                reservasala.setSala(sala);
                                LocalDateTime horario=rS.getObject("reservasala.disponibilidad",LocalDateTime.class);
                                reservasala.setDisponibilidadReserva(horario);


                                mapa.put(reservasala.getId(), reservasala);
                            }


                            RecursoSalaShort recursosala = new RecursoSalaShort();
                            recursosala.setId(Integer.parseInt(rS.getString("recursosalaid")));


                            reservasala.annadirListaRecursoSala(recursosala);





                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(ReservaSalaBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    try {
                        i = 0;
                        con.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(ReservaSalaBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            }
            else{
                //reservaSala=null;

            }
        } catch (SQLException ex) {
            Logger.getLogger(ReservaSalaBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ReservaSalaBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return mapa.values();


    }


    public boolean deleteReservaSala(int id){

        boolean valor= false;

        try {
            if (conector() == true) {

                con.setAutoCommit(false);

                ReservaSala reservasala = new ReservaSala();
                Usuario us = new Usuario();
                BibliotecaShort biblioteca= new BibliotecaShort();
                SalaShort sala=new SalaShort();

                reservasala=getReservaSala(id);



                us = reservasala.getUs();
                System.out.println("El ID del recursoSala " +us.getId());
                biblioteca= reservasala.getBiblioteca();
                int bibliotecaID= biblioteca.getId();
                System.out.println("El ID de la biblioteca " + bibliotecaID);
                sala =  reservasala.getSala();
                int salaID= sala.getId();
                System.out.println("El ID del recursoSala" + salaID);
                ArrayList<RecursoSalaShort> recursosala= new ArrayList<>();
                recursosala = reservasala.getListaRecursoSala();
                System.out.println("El tamaño de la lista de recursoSala es " + recursosala.size());
                LocalDateTime horario = reservasala.getDisponibilidadReserva();
                System.out.println("El horario de la reserva de la sala" + horario);




                //  String queryBD = "INSERT INTO disponibilidadbiblioteca (bibliotecaID,disponibilidad) VALUES (" + bibliotecaID + ", '" + horario + "');";
                String queryBD1= "INSERT INTO disponibilidadsala (salaid,disponibilidad) VALUES (" + salaID + ", '" + horario + "');";

                System.out.println(queryBD1);
                String queryBD2 = "delete from reservasala where id="+id+";";
                System.out.println(queryBD2);

                if(conector()==true) {
                    try {
                        con.setAutoCommit(false);

                        System.out.println("Antes de la query");
                        createStatement.executeUpdate(queryBD1);
                        System.out.println("Después de la query");
                        for (RecursoSalaShort recursoSala : recursosala) {
                            int recursoSalaID = recursoSala.getId();
                            System.out.println("El ID del recurso sala" + recursoSalaID);
                            createStatement.executeUpdate("INSERT INTO disponibilidadrecursosala (recursosalaid,disponibilidad) VALUES (" + recursoSalaID + ", '" + horario + "');");
                        }
                        createStatement.executeUpdate(queryBD2);

                        con.commit();
                        con.setAutoCommit(true);
                        con.close();
                        valor = true;
                        //return valor;


                    } catch (SQLException ex) {
                        Logger.getLogger(ReservaSalaBD.class.getName()).log(Level.SEVERE, null, ex);
                        con.rollback();
                    }
                }

                try {

                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(ReservaSalaBD.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
            else{

            }
        } catch (SQLException ex) {
            Logger.getLogger(ReservaSalaBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ReservaSalaBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return valor;
    }

}
