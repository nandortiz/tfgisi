package services;


import entities.*;

import java.sql.Statement;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BibliotecaBD extends ConexionBD{

    private static BibliotecaBD instance;
    public static BibliotecaBD getInstance() {
        if (instance == null) {
            instance = new BibliotecaBD();
        }
        return instance;
    }


    public Biblioteca addBiblioteca(Biblioteca biblioteca) throws SQLException, ClassNotFoundException {
        int identificador= -1;
        if (conector() == true) {
            con.setAutoCommit(false);
            try {

                String nombre = biblioteca.getNombreBiblioteca();
                String descripcion = biblioteca.getDescripcionBiblioteca();
                ArrayList<LocalDateTime> disponibilidad = new ArrayList<>();
                disponibilidad=  biblioteca.getListaDisponibilidadBiblioteca();


                createStatement.executeUpdate("INSERT INTO biblioteca (nombre,descripcion) VALUES ('" + nombre + "', '" + descripcion + "');",Statement.RETURN_GENERATED_KEYS);
                ResultSet prueba = createStatement.getGeneratedKeys();
                prueba.next();
                identificador=prueba.getInt(1);
                System.out.println("la fila es " + identificador );
                String patron = "/bibliotecas/";
                String url = patron+identificador;
                createStatement.executeUpdate("UPDATE  biblioteca set url ='" + url + "' where id = "+ identificador + ";");

                for (LocalDateTime dis:disponibilidad) {

                    createStatement.executeUpdate("INSERT INTO disponibilidadbiblioteca (bibliotecaid,disponibilidad) VALUES (" + identificador + ", '" + dis +  "');");
                }
                con.commit();
                con.setAutoCommit(true);
                con.close();
            }
            catch(SQLException e){
                e.printStackTrace();
                con.rollback();
            }

        }
        //return biblioteca;
        return getBiblioteca(identificador);
        //return url;
    }


    public Biblioteca getBiblioteca(int id) {

        HashMap<Integer,Biblioteca> mapa = new HashMap<>();
        try {
            if(conector()==true){

                String queryBD= "select biblioteca.id, biblioteca.url, biblioteca.nombre, biblioteca.descripcion, disponibilidadbiblioteca.disponibilidad from biblioteca inner join disponibilidadbiblioteca on biblioteca.id = disponibilidadbiblioteca.bibliotecaid where biblioteca.id =" +id + " ;";
                String queryBD1= "select biblioteca.id, biblioteca.url, biblioteca.nombre, biblioteca.descripcion, puesto.id as PuestoID, puesto.url as puestoURL, puesto.descripcion as puestoDescripcion, puesto.bibliotecaid as puestoBibliotecaID, from biblioteca INNER JOIN puesto on biblioteca.id = puesto.bibliotecaid where biblioteca.id =" +id +  " ;";
                String queryBD2= "select biblioteca.id, biblioteca.url, biblioteca.nombre, biblioteca.descripcion, sala.id as SalaID, sala.url as salaURL, sala.descripcion as salaDescripcion, sala.bibliotecaid as salaBibliotecaID, from biblioteca INNER JOIN sala on biblioteca.id = sala.bibliotecaid where biblioteca.id =" +id +  " ;";
                int i=0;

                try {

                    rS = createStatement.executeQuery(queryBD);

                } catch (SQLException ex) {
                    System.out.println("Falla esto 0");
                    ex.printStackTrace();
                    Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
                }


                if (rS == null){
                    System.out.println("la consulta esta vacia");
                    //lab= null;

                }
                else{

                    try {
                        //rS = createStatement.executeQuery(queryBD);
                        while (rS.next()) {

                            Biblioteca biblioteca;

                            if (mapa.containsKey(Integer.parseInt(rS.getString("biblioteca.id")))){
                                biblioteca=mapa.get(Integer.parseInt(rS.getString("biblioteca.id")));
                            }
                            else{
                                biblioteca = new Biblioteca();
                                biblioteca.setId(Integer.parseInt(rS.getString("biblioteca.id")));
                                biblioteca.setUrl(rS.getString("biblioteca.url"));
                                biblioteca.setNombreBiblioteca(rS.getString("biblioteca.nombre"));
                                biblioteca.setDescripcionBiblioteca(rS.getString("biblioteca.descripcion"));
                                mapa.put(biblioteca.getId(), biblioteca);
                            }


                            LocalDateTime tiempo = rS.getObject("disponibilidadbiblioteca.disponibilidad",LocalDateTime.class);
                            biblioteca.annadirListaDisponibilidadBiblioteca(tiempo);


                        }
                        rS1 = createStatement.executeQuery(queryBD1);
                        while(rS1.next()){
                            Biblioteca biblioteca=null;
                            if (mapa.containsKey(Integer.parseInt(rS1.getString("biblioteca.id")))){
                                biblioteca=mapa.get(Integer.parseInt(rS1.getString("biblioteca.id")));

                            }
                            PuestoShort puesto = new PuestoShort();
                            puesto.setId(Integer.parseInt(rS1.getString("puestoID")));
                            puesto.setUrl(rS1.getString("puestoURL"));
                            puesto.setDescripcionPuesto(rS1.getString("puestoDescripcion"));
                            puesto.setBibliotecaID(Integer.parseInt(rS1.getString("puestobibliotecaID")));

                            biblioteca.annadirListaPuesto(puesto);


                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    try {
                        i = 0;
                        con.close();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
                    }


                }

            }
            else{
                System.out.println("La conexión ha fallado");
                //biblioteca=null;

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
            Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (mapa.values().size() >0){


            return new ArrayList<>(mapa.values()).get(0);

        }
        else {
            return null;

        }


    }


    public Collection<BibliotecaShort> getAllBibliotecas() {

        HashMap<Integer,BibliotecaShort> mapa = new HashMap<>();

        try {
            if(conector()==true){
                String queryBD= "select id, url, nombreBiblioteca, descripcionBiblioteca from biblioteca";
                int i=0;
                try {
                    rS = createStatement.executeQuery(queryBD);
/*
                    while (rS.next()) {

                        Biblioteca biblioteca= getBiblioteca(Integer.parseInt(rS.getString("id")));
                        mapa.put(lab.getId(), biblioteca);

                    }


 */
                    while(rS.next()){
                        BibliotecaShort biblioteca;

                        if (mapa.containsKey(Integer.parseInt(rS.getString("id")))){
                            biblioteca=mapa.get(Integer.parseInt(rS.getString("id")));
                        }
                        else{
                            biblioteca = new BibliotecaShort();
                            biblioteca.setId(Integer.parseInt(rS.getString("id")));
                            biblioteca.setUrl(rS.getString("url"));
                            biblioteca.setNombreBiblioteca(rS.getString("nombreBiblioteca"));
                            biblioteca.setDescripcionBiblioteca(rS.getString("descripcionBiblioteca"));
                            mapa.put(biblioteca.getId(), biblioteca);
                        }
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    i=0;
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
            else{
                //return new ArrayList<>(mapa.values);
                //return null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("El tamaño de la lista es" + mapa.values().size());
        return mapa.values();

    }

    public Biblioteca updateBiblioteca(Biblioteca biblioteca, int id) throws SQLException, ClassNotFoundException {
        try {
            if (conector() == true) {
                // int id = biblioteca.getId();
                //String url = biblioteca.getUrl();
                String nombre = biblioteca.getNombreBiblioteca();
                String descripcion= biblioteca.getDescripcionBiblioteca();

                String queryBD = "update laboratorio set nombreBiblioteca='"+nombre+"', descripcionBiblioteca='"+descripcion+"' where id="+id+";";

                try {
                    createStatement.executeUpdate(queryBD);
                } catch (SQLException ex) {
                    Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
                }

                try {

                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else{
                return null;

            }
        } catch (SQLException ex) {
            Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return getBiblioteca(id);
    }

    public  CambioHorario cambioBiblioteca(CambioHorario cam, int id) throws SQLException, ClassNotFoundException {
        try {
            if (conector() == true) {
                switch (cam.getTipo()) {

                    case ADD:
                        //insert tabla disponibilidadBiblioteca con el id y la franja
                        LocalDateTime franja = cam.getFranja();
                        createStatement.executeUpdate("INSERT INTO disponibilidadbiblioteca (bibliotecaid,disponibilidad) VALUES (" + id + ", '" + franja + "');");
                        break;

                    case REMOVE:
                        //delete tabla disponibilidadBiblioteca con el id y la franja
                        LocalDateTime franjaRemove = cam.getFranja();
                        createStatement.executeUpdate("delete from disponibilidadbiblioteca where bibliotecaid="+id+" AND disponibilidad='" + franjaRemove+ "';");
                        break;


                }

            }
        } catch (SQLException ex) {
            Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
        }

        return cam;
    }
    public boolean deleteBiblioteca(int id) throws SQLException, ClassNotFoundException {
        boolean valor= false;
        try {
            if (conector() == true) {

                String queryBD = "delete from biblioteca where id="+id+";";

                try {
                    createStatement.executeUpdate(queryBD);
                    valor = true;
                    return valor;
                } catch (SQLException ex) {
                    Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
                }

                try {

                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else{

            }
        } catch (SQLException ex) {
            Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return valor;
    }


}
