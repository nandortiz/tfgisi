package services;

import entities.CambioHorario;
import entities.RecursoPuesto;
import entities.RecursoPuestoShort;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RecursoPuestoBD extends ConexionBD{


    private static RecursoPuestoBD instance;
    public static RecursoPuestoBD getInstance() {
        if (instance == null) {
            instance = new RecursoPuestoBD();
        }
        return instance;
    }




    public RecursoPuesto addRecursoPuesto(RecursoPuesto recursoPuesto, int bibliotecaID, int puestoID) throws SQLException, ClassNotFoundException {
        int identificador= -1;
        if (conector() == true) {
            con.setAutoCommit(false);
            try {


                String nombre = recursoPuesto.getNombreRecursoPuesto();
                String descripcion = recursoPuesto.getDescripcionRecursoPuesto();
                ArrayList<LocalDateTime> disponibilidad = new ArrayList<>();
                disponibilidad= recursoPuesto.getListaDisponibilidadRecursoPuesto();

                createStatement.executeUpdate("INSERT INTO recursoPuesto(nombreRecursoPuesto,descripcionRecursoPuesto,bibliotecaid, puestoid) VALUES ('" + nombre + "', '" + descripcion + "', " + bibliotecaID+ ", "  + puestoID+");",Statement.RETURN_GENERATED_KEYS);
                ResultSet prueba = createStatement.getGeneratedKeys();
                prueba.next();
                identificador=prueba.getInt(1);
                System.out.println("la fila es " + identificador );
                String patron = "/bibliotecas/" + bibliotecaID + "/puestos/" + puestoID + "/recursosPuestos/";
                String url = patron+identificador;
                createStatement.executeUpdate("UPDATE  recursopuesto set url ='" + url + "' where id = "+ identificador + ";");

                for (LocalDateTime dis:disponibilidad) {

                    createStatement.executeUpdate("INSERT INTO disponibilidadrecursopuesto (recursopuestoid,disponibilidad) VALUES (" + identificador + ", '" + dis +  "');");
                }
                con.commit();
                con.setAutoCommit(true);
                con.close();
            }
            catch(SQLException e){
                con.rollback();
            }

        }
        //return recursoPuesto;
        return getRecursoPuesto(bibliotecaID, puestoID , identificador);
    }

    public RecursoPuesto getRecursoPuesto(int bibliotecaID, int puestoID , int id) {

        HashMap<Integer,RecursoPuesto> mapa = new HashMap<>();
        try {
            if(conector()==true){

                String queryBD = "select recursopuesto.id, recursopuesto.url, recursopuesto.nombreRecursoPuesto , recursopuesto.descripcionRecursoPuesto, recursopuesto.bibliotecaid, recursopuesto.puestoid, disponibilidadrecursopuesto.disponibilidad from recursopuesto inner join disponibilidadrecursopuesto on recursopuesto.id = disponibilidadrecursopuesto.recursopuestoid where recursopuesto.id =" + id +" AND recursopuesto.bibliotecaid= " + bibliotecaID + " AND recursopuesto.puestoid= "+ puestoID+" ;";
                int i=0;

                try {

                    rS = createStatement.executeQuery(queryBD);
                } catch (SQLException ex) {
                    Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (rS == null){
                    //banco= null;

                }
                else{

                    try {
                        while (rS.next()) {
                            RecursoPuesto recursoPuesto;

                            if (mapa.containsKey(Integer.parseInt(rS.getString("recursosbancodetrabajo.id")))){
                                recursoPuesto=mapa.get(Integer.parseInt(rS.getString("recursosbancodetrabajo.id")));

                            }
                            else{

                                recursoPuesto = new RecursoPuesto();
                                recursoPuesto.setId(Integer.parseInt(rS.getString("recursopuesto.id")));
                                recursoPuesto.setUrl(rS.getString("recursopuesto.url"));
                                recursoPuesto.setNombreRecursoPuesto(rS.getString("recursopuesto.nombreRecursoPuesto"));
                                recursoPuesto.setDescripcionRecursoPuesto(rS.getString("recursopuesto.descripcionRecursoPuesto"));
                                recursoPuesto.setBibliotecaID(Integer.parseInt(rS.getString("recursopuesto.bibliotecaID")));
                                recursoPuesto.setPuestoID(Integer.parseInt(rS.getString("recursopuesto.puestoID")));


                                mapa.put(recursoPuesto.getId(), recursoPuesto);
                            }


                            LocalDateTime tiempo = rS.getObject("disponibilidadrecursopuesto.disponibilidad",LocalDateTime.class);

                            recursoPuesto.annadirListaDisponibilidadRecursoPuesto(tiempo);





                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    try {
                        i = 0;
                        con.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            }
            else{
                //puesto=null;

            }
        } catch (SQLException ex) {
            Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (mapa.values().size() >0){


            return new ArrayList<>(mapa.values()).get(0);

        }
        else {
            return null;
        }


    }

    public Collection<RecursoPuestoShort> getAllRecursoPuesto(int bibliotecaID, int puestoID) {

        HashMap<Integer,RecursoPuestoShort> mapa = new HashMap<>();

        try {
            if(conector()==true){
                String queryBD = "select id, url, nombreRecursoPuesto ,descripcionRecursoPuesto, bibliotecaid ,puestoid from recursopuesto  WHERE recursopuesto.puestoid= "+ puestoID+ " AND recursopuesto.bibliotecaid= " + bibliotecaID + ";";
                int i=0;
                try {
                    rS = createStatement.executeQuery(queryBD);

                    while (rS.next()) {

                        RecursoPuestoShort recursoPuesto;

                        if (mapa.containsKey(Integer.parseInt(rS.getString("id")))){
                            recursoPuesto=mapa.get(Integer.parseInt(rS.getString("id")));
                        }
                        else{
                            recursoPuesto = new RecursoPuestoShort();
                            recursoPuesto.setId(Integer.parseInt(rS.getString("id")));
                            recursoPuesto.setUrl(rS.getString("url"));
                            recursoPuesto.setNombreRecursoPuesto(rS.getString("nombreRecursoPuesto"));
                            recursoPuesto.setDescripcionRecursoPuesto(rS.getString("descripcionRecursoPuesto"));
                            recursoPuesto.setBibliotecaID(Integer.parseInt(rS.getString("bibliotecaid")));
                            recursoPuesto.setPuestoID(Integer.parseInt(rS.getString("bibliotecaid")));
                            mapa.put(recursoPuesto.getId(), recursoPuesto);
                        }


                    }
                } catch (SQLException ex) {
                    Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    i=0;
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
            else{
                //return new ArrayList<>(mapa.values);
                return null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return mapa.values();

    }

    public RecursoPuesto updateRecursoPuesto(RecursoPuesto recursoPuesto,int bibliotecaID, int puestoID, int id) throws SQLException, ClassNotFoundException {
        try {
            if (conector() == true) {

                String nombre = recursoPuesto.getNombreRecursoPuesto();
                String descripcion= recursoPuesto.getDescripcionRecursoPuesto();


                String queryBD = "update recursopuesto set nombreRecursoPuesto='" + nombre + "', descripcionRecursoPuesto ='" + descripcion + "'  where id="+id+" AND puestoid= " + puestoID+" AND bibliotecaid= " + bibliotecaID+ " ;";

                try {
                    createStatement.executeUpdate(queryBD);
                } catch (SQLException ex) {
                    Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }

                try {

                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else{

            }
        } catch (SQLException ex) {
            Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return getRecursoPuesto(bibliotecaID, puestoID, id);
    }


    public CambioHorario cambioRecursoPuesto(CambioHorario cam, int bibliotecaID, int puestoID, int id) throws SQLException, ClassNotFoundException {
        try {
            if (conector() == true) {
                switch (cam.getTipo()) {

                    case ADD:
                        //insert tabla disponibilidadPuesto con el id y la franja
                        LocalDateTime franja = cam.getFranja();
                        createStatement.executeUpdate("INSERT INTO disponibilidadrecursopuesto (recursopuestoid,disponibilidad) VALUES (" + id + ", '" + franja + "');");
                        break;

                    case REMOVE:
                        //delete tabla disponibilidadBiblioteca con el id y la franja
                        LocalDateTime franjaRemove = cam.getFranja();
                        createStatement.executeUpdate("delete from disponibilidadrecursopuesto where recursopuestoid="+id+" AND disponibilidad='" + franjaRemove+ "';");
                        break;


                }

            }
        } catch (SQLException ex) {
            Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        }

        return cam;
    }

    public boolean deleteRecursoPuesto(int bibliotecaID, int puestoID, int id) throws SQLException, ClassNotFoundException {
        boolean valor= false;
        try {
            if (conector() == true) {

                String queryBD = "delete from recursopuesto where id="+id+" AND bancoid = "+ puestoID + ";";

                try {
                    createStatement.executeUpdate(queryBD);
                    valor = true;
                    return valor;
                } catch (SQLException ex) {
                    Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }

                try {

                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else{

            }
        } catch (SQLException ex) {
            Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return valor;
    }

}
