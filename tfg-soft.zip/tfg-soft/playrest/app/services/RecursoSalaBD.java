package services;

import entities.CambioHorario;
import entities.RecursoSala;
import entities.RecursoSalaShort;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RecursoSalaBD extends ConexionBD{


    private static RecursoSalaBD instance;
    public static RecursoSalaBD getInstance() {
        if (instance == null) {
            instance = new RecursoSalaBD();
        }
        return instance;
    }




    public RecursoSala addRecursoSala(RecursoSala recursoSala, int bibliotecaID, int salaID) throws SQLException, ClassNotFoundException {
        int identificador= -1;
        if (conector() == true) {
            con.setAutoCommit(false);
            try {


                String nombre = recursoSala.getNombreRecursoSala();
                String descripcion = recursoSala.getDescripcionRecursoSala();
                ArrayList<LocalDateTime> disponibilidad = new ArrayList<>();
                disponibilidad= recursoSala.getListaDisponibilidadRecursoSala();

                createStatement.executeUpdate("INSERT INTO recursoSala(nombreRecursoSala,descripcionRecursoSala,bibliotecaid, puestoid) VALUES ('" + nombre + "', '" + descripcion + "', " + bibliotecaID+ ", "  + salaID+");",Statement.RETURN_GENERATED_KEYS);
                ResultSet prueba = createStatement.getGeneratedKeys();
                prueba.next();
                identificador=prueba.getInt(1);
                System.out.println("la fila es " + identificador );
                String patron = "/bibliotecas/" + bibliotecaID + "/salas/" + salaID + "/recursosSalas/";
                String url = patron+identificador;
                createStatement.executeUpdate("UPDATE  recursosala set url ='" + url + "' where id = "+ identificador + ";");

                for (LocalDateTime dis:disponibilidad) {

                    createStatement.executeUpdate("INSERT INTO disponibilidadrecursosala (recursosalaid,disponibilidad) VALUES (" + identificador + ", '" + dis +  "');");
                }
                con.commit();
                con.setAutoCommit(true);
                con.close();
            }
            catch(SQLException e){
                con.rollback();
            }

        }
        //return recursoSala;
        return getRecursoSala(bibliotecaID, salaID , identificador);
    }

    public RecursoSala getRecursoSala(int bibliotecaID, int salaID , int id) {

        HashMap<Integer,RecursoSala> mapa = new HashMap<>();
        try {
            if(conector()==true){

                String queryBD = "select recursosala.id, recursosala.url, recursosala.nombreRecursoSala , recursosala.descripcionRecursoSala, recursosala.bibliotecaid, recursosala.salaid, disponibilidadrecursosala.disponibilidad from recursosala inner join disponibilidadrecursosala on recursosala.id = disponibilidadrecursosala.recursosalaid where recursosala.id =" + id +" AND recursosala.bibliotecaid= " + bibliotecaID + " AND recursosala.salaid= "+ salaID+" ;";
                int i=0;

                try {

                    rS = createStatement.executeQuery(queryBD);
                } catch (SQLException ex) {
                    Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (rS == null){
                    //sala= null;

                }
                else{

                    try {
                        while (rS.next()) {
                            RecursoSala recursoSala;

                            if (mapa.containsKey(Integer.parseInt(rS.getString("recursosala.id")))){
                                recursoSala=mapa.get(Integer.parseInt(rS.getString("recursosala.id")));

                            }
                            else{

                                recursoSala = new RecursoSala();
                                recursoSala.setId(Integer.parseInt(rS.getString("recursosala.id")));
                                recursoSala.setUrl(rS.getString("recursosala.url"));
                                recursoSala.setNombreRecursoSala(rS.getString("recursosala.nombreRecursoSala"));
                                recursoSala.setDescripcionRecursoSala(rS.getString("recursosala.descripcionRecursoSala"));
                                recursoSala.setBibliotecaID(Integer.parseInt(rS.getString("recursosala.bibliotecaID")));
                                recursoSala.setSalaID(Integer.parseInt(rS.getString("recursosala.salaID")));


                                mapa.put(recursoSala.getId(), recursoSala);
                            }


                            LocalDateTime tiempo = rS.getObject("disponibilidadrecursosala.disponibilidad",LocalDateTime.class);

                            recursoSala.annadirListaDisponibilidadSala(tiempo);





                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(RecursoSalaBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    try {
                        i = 0;
                        con.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(RecursoSalaBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            }
            else{
                //puesto=null;

            }
        } catch (SQLException ex) {
            Logger.getLogger(RecursoSalaBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(RecursoSalaBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (mapa.values().size() >0){


            return new ArrayList<>(mapa.values()).get(0);

        }
        else {
            return null;
        }


    }

    public Collection<RecursoSalaShort> getAllRecursoSala(int bibliotecaID, int salaID) {

        HashMap<Integer,RecursoSalaShort> mapa = new HashMap<>();

        try {
            if(conector()==true){
                String queryBD = "select id, url, nombreRecursoSala ,descripcionRecursoSala, bibliotecaid ,salaid from recursosala  WHERE recursosala.salaid= "+ salaID+ " AND recursosala.bibliotecaid= " + bibliotecaID + ";";
                int i=0;
                try {
                    rS = createStatement.executeQuery(queryBD);

                    while (rS.next()) {

                        RecursoSalaShort recursoSala;

                        if (mapa.containsKey(Integer.parseInt(rS.getString("id")))){
                            recursoSala=mapa.get(Integer.parseInt(rS.getString("id")));
                        }
                        else{
                            recursoSala = new RecursoSalaShort();
                            recursoSala.setId(Integer.parseInt(rS.getString("id")));
                            recursoSala.setUrl(rS.getString("url"));
                            recursoSala.setNombreRecursoSala(rS.getString("nombreRecursoSala"));
                            recursoSala.setDescripcionRecursoSala(rS.getString("descripcionRecursoSala"));
                            recursoSala.setBibliotecaID(Integer.parseInt(rS.getString("bibliotecaid")));
                            recursoSala.setSalaID(Integer.parseInt(rS.getString("bibliotecaid")));
                            mapa.put(recursoSala.getId(), recursoSala);
                        }


                    }
                } catch (SQLException ex) {
                    Logger.getLogger(RecursoSalaBD.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    i=0;
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(RecursoSalaBD.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
            else{
                //return new ArrayList<>(mapa.values);
                return null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(RecursoSalaBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(RecursoSalaBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return mapa.values();

    }

    public RecursoSala updateRecursoSala(RecursoSala recursoSala,int bibliotecaID, int salaID, int id) throws SQLException, ClassNotFoundException {
        try {
            if (conector() == true) {

                String nombre = recursoSala.getNombreRecursoSala();
                String descripcion= recursoSala.getDescripcionRecursoSala();


                String queryBD = "update recursosala set nombreRecursoSala='" + nombre + "', descripcionRecursoSala ='" + descripcion + "'  where id="+id+" AND salaid= " + salaID+" AND bibliotecaid= " + bibliotecaID+ " ;";

                try {
                    createStatement.executeUpdate(queryBD);
                } catch (SQLException ex) {
                    Logger.getLogger(RecursoSalaBD.class.getName()).log(Level.SEVERE, null, ex);
                }

                try {

                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(RecursoSalaBD.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else{

            }
        } catch (SQLException ex) {
            Logger.getLogger(RecursoSalaBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(RecursoPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return getRecursoSala(bibliotecaID, salaID, id);
    }


    public CambioHorario cambioRecursoSala(CambioHorario cam, int bibliotecaID, int salaID, int id) throws SQLException, ClassNotFoundException {
        try {
            if (conector() == true) {
                switch (cam.getTipo()) {

                    case ADD:
                        //insert tabla disponibilidadSala con el id y la franja
                        LocalDateTime franja = cam.getFranja();
                        createStatement.executeUpdate("INSERT INTO disponibilidadrecursosala (recursosalaid,disponibilidad) VALUES (" + id + ", '" + franja + "');");
                        break;

                    case REMOVE:
                        //delete tabla disponibilidadBiblioteca con el id y la franja
                        LocalDateTime franjaRemove = cam.getFranja();
                        createStatement.executeUpdate("delete from disponibilidadrecursosala where recursosalaid="+id+" AND disponibilidad='" + franjaRemove+ "';");
                        break;


                }

            }
        } catch (SQLException ex) {
            Logger.getLogger(RecursoSalaBD.class.getName()).log(Level.SEVERE, null, ex);
        }

        return cam;
    }

    public boolean deleteRecursoSala(int bibliotecaID, int salaID, int id) throws SQLException, ClassNotFoundException {
        boolean valor= false;
        try {
            if (conector() == true) {

                String queryBD = "delete from recursosala where id="+id+" AND salaid = "+ salaID + ";";

                try {
                    createStatement.executeUpdate(queryBD);
                    valor = true;
                    return valor;
                } catch (SQLException ex) {
                    Logger.getLogger(RecursoSalaBD.class.getName()).log(Level.SEVERE, null, ex);
                }

                try {

                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(RecursoSalaBD.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else{

            }
        } catch (SQLException ex) {
            Logger.getLogger(RecursoSalaBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(RecursoSalaBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return valor;
    }

}
