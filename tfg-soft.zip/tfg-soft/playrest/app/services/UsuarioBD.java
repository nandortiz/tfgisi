package services;

import entities.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import static services.ConexionBD.con;


public class UsuarioBD extends   ConexionBD {
    private static UsuarioBD instance;

    public static UsuarioBD getInstance() {
        if (instance == null) ;
        instance = new UsuarioBD();

        return instance;

}

    public Usuario addUsuario(Usuario us) throws SQLException, ClassNotFoundException {
        int identificador = -1;

        if (conector() == true) {

            String nombre = us.getNombre();
            String grado = us.getGrado();
            String apellidos = us.getApellidos();

            createStatement.executeUpdate("INSERT INTO usuario (nombre, apellidos, grado) VALUES('" + nombre + "','" + apellidos + "','" + grado + "');", Statement.RETURN_GENERATED_KEYS);
            ResultSet prueba = createStatement.getGeneratedKeys();
            prueba.next();
            identificador = prueba.getInt(1);
            System.out.println("la fila es " + identificador);
            String patron = "/usuarios/";
            String url = patron + identificador;
            createStatement.executeUpdate("UPDATE usuario set url ='" + url + "', " + identificador+ ";");

            con.close();


        }
        return getUsuario(identificador);
    }

    public Usuario getUsuario(int id) {
        //Usuario us = new Usuario();
        HashMap<Integer, Usuario> mapa = new HashMap();
        try {
            if (conector() == true) {
                System.out.println("Antes de guardar la query");
                String queryBD = "select usuario.id, usuario.url,usuario.nombre, usuario.apellidos, usuario.grado from usuario where usuario.id=" + id + ";";
                String queryBD1 = "select usuario.id, usuario.url,usuario.nombre, usuario.apellidos, usuario.grado, reserva.id as ReservaID, reserva.url as ReservaURL, reserva.disponibilidad as Disponibilidad from usuario inner join reserva on usuario.id = reserva.usuarioID where usuario.id=" + id + ";";
                System.out.println("Después de la query");
                int i = 0;
                try {
                    rS = createStatement.executeQuery(queryBD);
                } catch (SQLException ex) {
                    Logger.getLogger(UsuarioBD.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (rS == null) {
                    //us=null;
                } else {
                    try {
                        while (rS.next()) {
                            System.out.println("En la query");
                            Usuario us;
                            if (mapa.containsKey(Integer.parseInt(rS.getString("usuario.id")))) {
                                us = mapa.get(Integer.parseInt(rS.getString("usuario.id")));
                            } else {
                                System.out.println("En el else");
                                us = new Usuario();
                                us.setId(rS.getInt("usuario.id"));

                                us.setUrl(rS.getString("usuario.url"));

                                us.setNombre(rS.getString("usuario.nombre"));

                                us.setNombre(rS.getString("usuario.apellidos"));

                                us.setGrado(rS.getString("usuario.grado"));

                                mapa.put(us.getId(), us);

                                System.out.println("Al final del primer statement");
                            }
                        }
                        System.out.println("Antes del nuevo statement");
                        rS1 = createStatement.executeQuery(queryBD1);
                        while (rS1.next()) {
                            System.out.println("Dentro del nuevo statement");
                            Usuario us = null;
                            if (mapa.containsKey(Integer.parseInt(rS1.getString("usuario.id")))) {
                                us = mapa.get(Integer.parseInt(rS1.getString("usuario.id")));

                            }
                            ReservaShort reserva = new ReservaShort();
                            reserva.setId(Integer.parseInt(rS1.getString("ReservaID")));
                            System.out.println("ID de la reserva" + reserva.getId());
                            reserva.setUrl(rS1.getString("ReservaURL"));
                            System.out.println("ID de la reserva" + reserva.getUrl());
                            reserva.setDisponibilidadReserva(rS1.getObject("Disponibilidad", LocalDateTime.class));
                            System.out.println("ID de la reserva" + reserva.getDisponibilidadReserva());
                            System.out.println("antes de añadir el nuevo statement");
                            // us.annadirReservas(reserva);
                            us.annadirReservas(reserva);

                            System.out.println("Al final del todo");
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        Logger.getLogger(UsuarioBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    try {
                        i = 0;
                        con.close();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        Logger.getLogger(UsuarioBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            } else {
                //us = null;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            Logger.getLogger(UsuarioBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        if(mapa.values().size()>0){
            return new ArrayList<>(mapa.values()).get(0);

        }
        else {
            return null;
        }


    }

public ArrayList<Usuario> getAllUsuarios(){
    ArrayList<Usuario> usuariosLista=new ArrayList<>();
    try{
        if(conector()==true){
            String queryBD="select * from usuario;";
            int i=0;
            try{
                rS=createStatement.executeQuery(queryBD);

                while (rS.next()) {
                    Usuario us = new Usuario();
                    us.setId(Integer.parseInt(rS.getString("id")));
                    us.setUrl(rS.getString("url"));
                    us.setNombre(rS.getString("nombre"));
                    us.setApellidos(rS.getString("apellidos"));
                    us.setGrado(rS.getString("grado"));
                    usuariosLista.add(us);

                }
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioBD.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                i=0;
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioBD.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        else{
            return usuariosLista;
        }
    } catch (SQLException ex) {
        Logger.getLogger(UsuarioBD.class.getName()).log(Level.SEVERE, null, ex);
    } catch (ClassNotFoundException ex) {
        Logger.getLogger(UsuarioBD.class.getName()).log(Level.SEVERE, null, ex);
    }
    System.out.println("El tamaño de la lista es" + usuariosLista.size());
    return usuariosLista;

}
    public Usuario updateUsuario(Usuario us, int id ) throws SQLException, ClassNotFoundException {
        try {
            if (conector() == true) {
                //int id = usu.getId();
                //String url = usu.getUrl();
                String nombre = us.getNombre();
                String apellidos = us.getApellidos();
                String grado= us.getGrado();

                String queryBD = "update usuario set nombre ='"+nombre+"', set apellidos = '"+apellidos +"', grado='"+grado+"' where id="+id+";";

                try {
                    createStatement.executeUpdate(queryBD);
                } catch (SQLException ex) {
                    Logger.getLogger(UsuarioBD.class.getName()).log(Level.SEVERE, null, ex);
                }

                try {

                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(UsuarioBD.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else{

            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UsuarioBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return getUsuario(id);
    }


    public boolean deleteUsuario(int id) throws SQLException, ClassNotFoundException {
        boolean valor= false;
        try {
            if (conector() == true) {

                String queryBD = "delete from usuario where id="+id+";";

                try {
                    createStatement.executeUpdate(queryBD);
                    valor = true;
                    return valor;
                } catch (SQLException ex) {
                    Logger.getLogger(UsuarioBD.class.getName()).log(Level.SEVERE, null, ex);
                }

                try {

                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(UsuarioBD.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else{

            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UsuarioBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return valor;
    }
}


