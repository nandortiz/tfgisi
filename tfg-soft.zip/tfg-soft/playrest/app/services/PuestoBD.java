package services;

import entities.*;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PuestoBD extends ConexionBD {

    private static PuestoBD instance;
    public static PuestoBD getInstance() {
        if (instance == null) {
            instance = new PuestoBD();
        }
        return instance;
    }


    public Puesto addPuesto(Puesto puesto, int bibliotecaID) throws SQLException, ClassNotFoundException {
        int identificador= -1;
        if (conector() == true) {
            con.setAutoCommit(false);
            try {


                String descripcion = puesto.getDescripcionPuesto();
                ArrayList<LocalDateTime> disponibilidadPuesto = new ArrayList<>();
                disponibilidadPuesto= puesto.getListaDisponibilidadPuesto();

                System.out.println("El identificador de la biblioteca es: " + bibliotecaID);
                createStatement.executeUpdate("INSERT INTO puesto (descripcion,bibliotecaID) VALUES ('" + descripcion + "', " + bibliotecaID+");",Statement.RETURN_GENERATED_KEYS);
                ResultSet prueba = createStatement.getGeneratedKeys();
                prueba.next();
                identificador=prueba.getInt(1);
                System.out.println("la fila es " + identificador );
                String patron = "/bibliotecas/" + bibliotecaID + "/puestos/";
                String url = patron+identificador;
                createStatement.executeUpdate("UPDATE  puesto set url ='" + url + "' where id = "+ identificador + ";");

                for (LocalDateTime dispo:disponibilidadPuesto) {

                    createStatement.executeUpdate("INSERT INTO disponibilidadpuesto (puestoid,disponibilidad) VALUES (" + identificador + ", '" + dispo +  "');");
                }
                con.commit();
                con.setAutoCommit(true);
                con.close();
            }
            catch(SQLException e){
                con.rollback();
            }

        }
        // return puesto;
        return getPuesto(bibliotecaID,identificador);
    }

    public Puesto getPuesto(int bibliotecaID, int id) {

        HashMap<Integer,Puesto> mapa = new HashMap<>();
        try {
            if(conector()==true){

                String queryBD = "select puesto.id, puesto.url, puesto.descripcionPuesto, puesto.bibliotecaid, disponibilidadpuesto.disponibilidad  from puesto inner join disponibilidadpuesto on puesto.id = disponibilidadpuesto.puestoid where puesto.id =" + id + " AND puesto.bibliotecaid =" + bibliotecaID +" ;";
                String queryBD1="select puesto.id, puesto.url, puesto.descripcionPuesto, puesto.bibliotecaid , recursopuesto.id as recursoPuestoID , recursopuesto.url as recursoPuestoURL, recursopuesto.nombre as recursoPuestoNombre, recursopuesto.descripcion as recursoPuestoDescripcion, recursopuesto.bibliotecaid as recursoBibliotecaID, recursopuesto.puestoid as recursoPuestoID from puesto INNER JOIN recursopuesto on puesto.id = recursopuesto.puestoid  where puesto.id =" + id + " AND puesto.bibliotecaid =" + bibliotecaID +" ;";
                int i=0;

                try {

                    rS = createStatement.executeQuery(queryBD);
                } catch (SQLException ex) {
                    Logger.getLogger(PuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (rS == null){
                    return null;

                }
                else{

                    try {
                        while (rS.next()) {
                            Puesto puesto;

                            if (mapa.containsKey(Integer.parseInt(rS.getString("puesto.id")))){
                                puesto=mapa.get(Integer.parseInt(rS.getString("puesto.id")));

                            }
                            else{

                                puesto = new Puesto();
                                puesto.setId(Integer.parseInt(rS.getString("puesto.id")));
                                puesto.setUrl(rS.getString("puesto.url"));
                                puesto.setDescripcionPuesto(rS.getString("puesto.descripcionPuesto"));
                                puesto.setBibliotecaID(Integer.parseInt(rS.getString("puesto.bibliotecaid")));

                                mapa.put(puesto.getId(), puesto);
                            }


                            LocalDateTime tiempo = rS.getObject("disponibilidadpuesto.disponibilidad",LocalDateTime.class);

                            puesto.annadirListaDisponibilidadPuesto(tiempo);





                        }
                        rS1= createStatement.executeQuery(queryBD1);
                        while (rS1.next()) {
                            Puesto puesto=null;
                            if (mapa.containsKey(Integer.parseInt(rS1.getString("puesto.id")))){
                                puesto=mapa.get(Integer.parseInt(rS1.getString("puesto.id")));

                            }

                            RecursoPuestoShort recursoPuesto = new RecursoPuestoShort();

                            recursoPuesto.setId(Integer.parseInt(rS1.getString("recursoPuestoID")));
                            recursoPuesto.setUrl(rS1.getString("recursoPuestoURL"));
                            recursoPuesto.setNombreRecursoPuesto(rS1.getString("recursoPuestoNombre"));
                            recursoPuesto.setDescripcionRecursoPuesto(rS1.getString("recursoPuestoDescripcion"));
                            recursoPuesto.setBibliotecaID(Integer.parseInt(rS1.getString("recursobibliotecaID")));
                            recursoPuesto.setPuestoID(Integer.parseInt(rS1.getString("recursoPuestoID")));

                            puesto.annadirListaRecursoPuesto(recursoPuesto);
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(PuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    try {
                        i = 0;
                        con.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(PuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            }
            else{
                return null;

            }
        } catch (SQLException ex) {
            Logger.getLogger(PuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (mapa.values().size() >0){


            return new ArrayList<>(mapa.values()).get(0);

        }
        else {
            return null;
        }


    }

    public Collection<PuestoShort> getAllPuesto(int bibliotecaID) {

        HashMap<Integer,PuestoShort> mapa = new HashMap<>();

        try {
            if(conector()==true){
                String queryBD = "select id, url, descripcionPuesto, bibliotecaid  from puesto where bibliotecaid =" + bibliotecaID + " ;";
                int i=0;
                try {
                    rS = createStatement.executeQuery(queryBD);

                    while (rS.next()) {

                        PuestoShort puesto;

                        if (mapa.containsKey(Integer.parseInt(rS.getString("id")))){
                            puesto=mapa.get(Integer.parseInt(rS.getString("id")));
                        }
                        else{
                            puesto = new PuestoShort();
                            puesto.setId(Integer.parseInt(rS.getString("id")));
                            puesto.setUrl(rS.getString("url"));
                            puesto.setDescripcionPuesto(rS.getString("descripcionPuesto"));
                            puesto.setBibliotecaID(Integer.parseInt(rS.getString("bibliotecaid")));
                            mapa.put(puesto.getId(), puesto);
                        }

                    }
                } catch (SQLException ex) {
                    Logger.getLogger(PuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    i=0;
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(PuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
            else{
                //return new ArrayList<>(mapa.values);
                return null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(PuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        //System.out.println("El tamaño de la lista es" + mapa.values().size());
        return mapa.values();

    }

    public Puesto updatePuesto(Puesto puesto,int bibliotecaID, int id) throws SQLException, ClassNotFoundException {
        try {
            if (conector() == true) {
                // int id = puesto.getId();
                //String url = puesto.getUrl();

                String descripcion= puesto.getDescripcionPuesto();

                String queryBD = "update puesto set descripcionPuesto='"+descripcion+"' where id="+id+" AND bibliotecaid= " + bibliotecaID + ";";

                try {
                    createStatement.executeUpdate(queryBD);
                } catch (SQLException ex) {
                    Logger.getLogger(PuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }

                try {

                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(PuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else{

            }
        } catch (SQLException ex) {
            Logger.getLogger(PuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return getPuesto(bibliotecaID, id);
    }
    public CambioHorario cambioPuesto(CambioHorario cam, int bibliotecaID, int id) throws SQLException, ClassNotFoundException {
        try {
            if (conector() == true) {
                switch (cam.getTipo()) {

                    case ADD:
                        //insert tabla disponibilidadPuesto con el id y la franja
                        LocalDateTime franja = cam.getFranja();
                        createStatement.executeUpdate("INSERT INTO disponibilidadpuesto (puestoid,disponibilidad) VALUES (" + id + ", '" + franja + "');");
                        break;

                    case REMOVE:
                        //delete tabla disponibilidadBiblioteca con el id y la franja
                        LocalDateTime franjaRemove = cam.getFranja();
                        createStatement.executeUpdate("delete from disponibilidadpuesto where puestoid="+id+" AND disponibilidad='" + franjaRemove+ "';");
                        break;


                }

            }
        } catch (SQLException ex) {
            Logger.getLogger(BibliotecaBD.class.getName()).log(Level.SEVERE, null, ex);
        }

        return cam;
    }

    public boolean deletePuesto(int bibliotecaID,int id) throws SQLException, ClassNotFoundException {
        boolean valor= false;
        try {
            if (conector() == true) {

                String queryBD = "delete from puesto where id="+id+" AND bibliotecaid= " + bibliotecaID + ";";

                try {
                    createStatement.executeUpdate(queryBD);
                    valor = true;
                    return valor;
                } catch (SQLException ex) {
                    Logger.getLogger(PuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }

                try {

                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(PuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else{

            }
        } catch (SQLException ex) {
            Logger.getLogger(PuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return valor;
    }

}
