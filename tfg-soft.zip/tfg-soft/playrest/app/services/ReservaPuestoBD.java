package services;

import entities.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ReservaPuestoBD extends ConexionBD{

    private static ReservaPuestoBD instance;
    public static ReservaPuestoBD getInstance() {
        if (instance == null) {
            instance = new ReservaPuestoBD();
        }
        return instance;
    }

    public ReservaPuesto addReservaPuesto(ReservaPuesto reservapuesto) throws SQLException, ClassNotFoundException {
        int usID=0;  int bibliotecaID =0; int puestoID=0;
        int identificador= -1; int numberRow=-1;int numberRowLab= -1; int contadorRecursoPuesto=0;
        if (conector() == true) {
            con.setAutoCommit(false);
            try {

                Usuario us = reservapuesto.getUs();
                BibliotecaShort biblioteca= reservapuesto.getBiblioteca();
                PuestoShort pue =  reservapuesto.getPuesto();
                usID= us.getId();
                System.out.println("El ID del Usuario es el siguiente" +usID);
                bibliotecaID= biblioteca.getId();
                System.out.println("El ID de la Biblioteca es el siguiente" +bibliotecaID);
                puestoID= pue.getId();
                System.out.println("El ID del Puesto es el siguiente" +puestoID);

                LocalDateTime horario= reservapuesto.getDisponibilidadReserva();
                System.out.println("El horario de la reserva es el siguiente" +horario);


                ArrayList<RecursoPuestoShort> recursosPuesto= new ArrayList<>();
                System.out.println("El tamaño de la lista de recursoPuesto es: " + recursosPuesto.size());
                recursosPuesto = reservapuesto.getListaRecursoPuesto();
                System.out.println("El tamaño de la lista de recursoPuesto es: " + recursosPuesto.size());

                String queryBD1=("select count(*) from usuario where id="+ usID +";");
                String queryBD2=("select count(*) from disponibilidadbiblioteca where bibliotecaID="+ bibliotecaID +" AND disponibilidad = '"+ horario + "';");
                String queryBD3=("delete from disponibilidadpuesto where puestoid="+ puestoID +" AND disponibilidad = '"+ horario + "';");

                rS=createStatement.executeQuery(queryBD1);
                while (rS.next()){
                    numberRow =rS.getInt("count(*)");
                }
                if(numberRow==1){
                    System.out.println("El usuario está bien");
                    rS=createStatement.executeQuery(queryBD2);
                    while (rS.next()){
                        numberRowLab =rS.getInt("count(*)");
                    }
                    if(numberRowLab==1){
                        System.out.println("La biblioteca está bien");
                        createStatement.executeUpdate(queryBD3);
                        if(createStatement.getUpdateCount()==1){
                            System.out.println("El puesto de estudio está bien");
                            for (RecursoPuestoShort recurso : recursosPuesto) {
                                int recursoID= recurso.getId();
                                System.out.println("El tamaño de la lista de recursosPuesto es: " + recursosPuesto.size());
                                System.out.println("El ID del recurso es el siguiente " + recursoID );
                                createStatement.executeUpdate("delete from disponibilidadrecursopuesto where recursoid="+ recursoID +" AND disponibilidad = '"+ horario + "';");
                                if(createStatement.getUpdateCount()==1){
                                    contadorRecursoPuesto++;
                                }
                                System.out.println("el tamaño del contador es " + contadorRecursoPuesto);
                            }
                            if(contadorRecursoPuesto==recursosPuesto.size()){



                                createStatement.executeUpdate("INSERT INTO reservapuesto (usuarioid,bibliotecaid,puestoid, disponibilidad) VALUES (" + usID + ", " + bibliotecaID+ ", "  + puestoID+" ,'" + horario+ "' );", Statement.RETURN_GENERATED_KEYS);
                                ResultSet prueba = createStatement.getGeneratedKeys();
                                prueba.next();
                                identificador=prueba.getInt(1);
                                System.out.println("la fila es " + identificador );
                                String url = "/reservasPuestos/"+identificador;
                                createStatement.executeUpdate("UPDATE  reservapuesto set url ='" + url + "' where id = "+ identificador + ";");

                                for (RecursoPuestoShort recurso:recursosPuesto) {
                                    int recursoID= recurso.getId();
                                    createStatement.executeUpdate("INSERT INTO reservarecursopuesto (reservaPuestoId,recursoPuestoId) VALUES (" + identificador + ", " + recursoID +  ");");
                                }

                                con.commit();
                                con.setAutoCommit(true);
                                con.close();




                            }
                            else {
                                reservapuesto=null;
                                System.out.println("Algún recurso del puesto de estudio o la disponibilidad que busca no existe");
                                con.rollback();
                            }

                        }
                        else {
                            reservapuesto=null;
                            System.out.println("El puesto de estudio o la disponibilidad que busca no existe");
                            con.rollback();
                        }
                    }
                    else {
                        reservapuesto=null;
                        System.out.println("La biblioteca a la que quiere acudir o la disponibilidad que busca no existe");
                        con.rollback();
                    }

                }
                else {

                    reservapuesto=null;
                    System.out.println("El usuario que busca no existe");
                    con.rollback();
                }





            }

            catch(SQLException e){
                e.printStackTrace();
                con.rollback();
            }

        }
        //return reservapuesto;
        return getReservaPuesto(identificador);
    }

    public ReservaPuesto getReservaPuesto(int id) {
        int usuarioID = 0; int bibliotecaID=0; int puestoID=0; int recursoPuestoID=0;
        String usuarioURL; String bibliotecaURL; String puestoURL; String recursoPuestoURL;

        HashMap<Integer,ReservaPuesto> mapa = new HashMap<>();
        try {
            if(conector()==true){
                String queryBD= "select reservapuesto.id, reservapuesto.url, reservapuesto.usuarioid , reservapuesto.bibliotecaid, reservapuesto.puestoid,reservapuesto.disponibilidad, reservarecursopuesto.recursopuestoid as recursoPuestoID, usuario.url as usuarioURL, biblioteca.url as bibliotecaURL, puesto.url as puestoURL, recursopuesto.url as recursoPuestoURL from reservapuesto inner join reservarecursopuesto on reservapuesto.id = reservarecursopuesto.reservapuestoid inner join usuario on reservapuesto.usuarioid  =usuario.id inner join biblioteca on reservapuesto.bibliotecaID =biblioteca.id inner join puesto on reservapuesto.puestoid =puesto.id inner join recursopuesto on reservarecursopuesto.recursopuestoid =recursopuesto.id where reservapuesto.id =" + id+" ;";
                int i=0;

                try {

                    rS = createStatement.executeQuery(queryBD);

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    Logger.getLogger(ReservaPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (rS == null){
                    //puesto= null;

                }
                else{

                    try {

                        while (rS.next()) {

                            ReservaPuesto reservapuesto;

                            if (mapa.containsKey(Integer.parseInt(rS.getString("reservapuesto.id")))){

                                reservapuesto=mapa.get(Integer.parseInt(rS.getString("reservapuesto.id")));

                            }
                            else{
                                System.out.println("Nueva Reservas ");
                                reservapuesto = new ReservaPuesto();
                                Usuario us = new Usuario();
                                BibliotecaShort biblioteca= new BibliotecaShort();
                                PuestoShort puesto =new PuestoShort();

                                reservapuesto.setId(Integer.parseInt(rS.getString("reservapuesto.id")));
                                reservapuesto.setUrl(rS.getString("reservapuesto.url"));
                                usuarioID=Integer.parseInt(rS.getString("reservapuesto.usuarioid"));
                                us.setId(usuarioID);
                                usuarioURL=rS.getString("usuarioURL");
                                us.setUrl(usuarioURL);
                                reservapuesto.setUs(us);

                                bibliotecaID=Integer.parseInt(rS.getString("reservapuesto.bibliotecaid"));
                                biblioteca.setId(bibliotecaID);
                                bibliotecaURL=rS.getString("bibliotecaURL");
                                biblioteca.setUrl(bibliotecaURL);
                                reservapuesto.setBiblioteca(biblioteca);
                                puestoID=Integer.parseInt(rS.getString("reservabiblioteca.puestoid"));
                                puesto.setId(puestoID);
                                puestoURL=rS.getString("puestoURL");
                                puesto.setUrl(puestoURL);
                                reservapuesto.setPuesto(puesto);
                                LocalDateTime horario=rS.getObject("reservapuesto.disponibilidad",LocalDateTime.class);
                                reservapuesto.setDisponibilidadReserva(horario);


                                mapa.put(reservapuesto.getId(), reservapuesto);
                            }



                            RecursoPuestoShort recursoPuesto = new RecursoPuestoShort();
                            recursoPuesto.setId(Integer.parseInt(rS.getString("recursoPuestoID")));
                            recursoPuesto.setUrl(rS.getString("recursoPuestoURL"));


                            reservapuesto.annadirListaRecursoPuesto(recursoPuesto);






                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        Logger.getLogger(ReservaPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    try {
                        i = 0;
                        con.close();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        Logger.getLogger(ReservaPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            }
            else{
                //reservaPuesto=null;


            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            Logger.getLogger(ReservaPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
            Logger.getLogger(ReservaPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (mapa.values().size() >0){



            return new ArrayList<>(mapa.values()).get(0);

        }
        else {

            return null;

        }


    }

    public Collection<ReservaPuesto> getAllReservaPuesto() {
        int usuarioID = 0; int bibliotecaID=0; int puestoID=0; int recursoPuestoID=0;


        HashMap<Integer,ReservaPuesto> mapa = new HashMap<>();
        try {
            if(conector()==true){

                String queryBD= "select reservapuesto.id, reservapuesto.url, reservapuesto.usuarioid , reservapuesto.bibliotecaid, reservapuesto.puestoid,reservapuesto.disponibilidad, reservarecursopuesto.recursopuestoid as recursoPuestoID from reservapuesto inner join reservarecursopuesto on reservapuesto.id = reservarecursopuesto.reservapuestoid ;";
                int i=0;

                try {

                    rS = createStatement.executeQuery(queryBD);
                } catch (SQLException ex) {
                    Logger.getLogger(ReservaPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (rS == null){
                    //puesto= null;

                }
                else{

                    try {
                        while (rS.next()) {
                            ReservaPuesto reservapuesto;

                            if (mapa.containsKey(Integer.parseInt(rS.getString("reservapuesto.id")))){
                                reservapuesto=mapa.get(Integer.parseInt(rS.getString("reservapuesto.id")));

                            }
                            else{

                                reservapuesto = new ReservaPuesto();
                                Usuario us = new Usuario();
                                BibliotecaShort biblioteca= new BibliotecaShort();
                                PuestoShort puesto =new PuestoShort();

                                reservapuesto.setId(Integer.parseInt(rS.getString("reservapuesto.id")));
                                reservapuesto.setUrl(rS.getString("reservapuesto.url"));
                                usuarioID=Integer.parseInt(rS.getString("reservapuesto.usuarioid"));
                                us.setId(usuarioID);
                                reservapuesto.setUs(us);

                                bibliotecaID=Integer.parseInt(rS.getString("reservapuesto.bibliotecaid"));
                                biblioteca.setId(bibliotecaID);
                                reservapuesto.setBiblioteca(biblioteca);
                                puestoID=Integer.parseInt(rS.getString("reservapuesto.puestoid"));
                                puesto.setId(puestoID);
                                reservapuesto.setPuesto(puesto);
                                LocalDateTime horario=rS.getObject("reservapuesto.disponibilidad",LocalDateTime.class);
                                reservapuesto.setDisponibilidadReserva(horario);


                                mapa.put(reservapuesto.getId(), reservapuesto);
                            }


                            RecursoPuestoShort recursopuesto = new RecursoPuestoShort();
                            recursopuesto.setId(Integer.parseInt(rS.getString("recursopuestoid")));


                            reservapuesto.annadirListaRecursoPuesto(recursopuesto);





                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(ReservaPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    try {
                        i = 0;
                        con.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(ReservaPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            }
            else{
                //reservaPuesto=null;

            }
        } catch (SQLException ex) {
            Logger.getLogger(ReservaPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ReservaPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return mapa.values();


    }


    public boolean deleteReservaPuesto(int id){

        boolean valor= false;

        try {
            if (conector() == true) {

                con.setAutoCommit(false);

                ReservaPuesto reservapuesto = new ReservaPuesto();
                Usuario us = new Usuario();
                BibliotecaShort biblioteca= new BibliotecaShort();
                PuestoShort puesto=new PuestoShort();

                reservapuesto=getReservaPuesto(id);



                us = reservapuesto.getUs();
                System.out.println("El ID del recursoPuesto " +us.getId());
                biblioteca= reservapuesto.getBiblioteca();
                int bibliotecaID= biblioteca.getId();
                System.out.println("El ID de la biblioteca " + bibliotecaID);
                puesto =  reservapuesto.getPuesto();
                int puestoID= puesto.getId();
                System.out.println("El ID del recursoPuesto" + puestoID);
                ArrayList<RecursoPuestoShort> recursopuesto= new ArrayList<>();
                recursopuesto = reservapuesto.getListaRecursoPuesto();
                System.out.println("El tamaño de la lista de recursoPuesto es " + recursopuesto.size());
                LocalDateTime horario = reservapuesto.getDisponibilidadReserva();
                System.out.println("El horario de la reserva del puesto" + horario);




                //  String queryBD = "INSERT INTO disponibilidadbiblioteca (bibliotecaID,disponibilidad) VALUES (" + bibliotecaID + ", '" + horario + "');";
                String queryBD1= "INSERT INTO disponibilidadpuesto (puestoid,disponibilidad) VALUES (" + puestoID + ", '" + horario + "');";

                System.out.println(queryBD1);
                String queryBD2 = "delete from reservapuesto where id="+id+";";
                System.out.println(queryBD2);

                if(conector()==true) {
                    try {
                        con.setAutoCommit(false);

                        System.out.println("Antes de la query");
                        createStatement.executeUpdate(queryBD1);
                        System.out.println("Después de la query");
                        for (RecursoPuestoShort recursoPuesto : recursopuesto) {
                            int recursoPuestoID = recursoPuesto.getId();
                            System.out.println("El ID del recurso puesto" + recursoPuestoID);
                            createStatement.executeUpdate("INSERT INTO disponibilidadrecursopuesto (recursopuestoid,disponibilidad) VALUES (" + recursoPuestoID + ", '" + horario + "');");
                        }
                        createStatement.executeUpdate(queryBD2);

                        con.commit();
                        con.setAutoCommit(true);
                        con.close();
                        valor = true;
                        //return valor;


                    } catch (SQLException ex) {
                        Logger.getLogger(ReservaPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                        con.rollback();
                    }
                }

                try {

                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(ReservaPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
            else{

            }
        } catch (SQLException ex) {
            Logger.getLogger(ReservaPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ReservaPuestoBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return valor;
    }

}

