package controllers;

import entities.CambioHorario;
import entities.RecursoPuesto;
import entities.RecursoPuestoShort;
//import freemarker.template.Configuration;
//import freemarker.template.Template;
//import freemarker.template.TemplateExceptionHandler;
import play.mvc.Http;
import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import services.RecursoPuestoBD;
import utils.ApplicationUtil;

import java.sql.SQLException;
import java.util.Collection;

public class RecursoPuestoController extends Controller {


    private static final Logger logger = LoggerFactory.getLogger("controller");


    public Result create(Http.Request request, int bibliotecaID, int puestoID) throws SQLException, ClassNotFoundException {
        JsonNode json = request.body().asJson();
        if (json == null) {
            return badRequest(ApplicationUtil.createResponse("Expecting JSON data", false));
        }
        logger.debug("In RecursoPuestoBD.create(), input is: {}", json.toString());
        RecursoPuesto recursoPuesto  = RecursoPuestoBD.getInstance().addRecursoPuesto(Json.fromJson(json, RecursoPuesto.class),bibliotecaID,puestoID);
        JsonNode jsonObject = Json.toJson(recursoPuesto);
        return created(ApplicationUtil.createResponse(jsonObject, true)).withHeader(LOCATION,recursoPuesto.getUrl());
    }

    public Result update(Http.Request request,int bibliotecaID, int puestoID,int id) throws SQLException, ClassNotFoundException {
        logger.debug("In RecursoPuestoController.update()");
        JsonNode json = request.body().asJson();

        if (json == null) {
            return badRequest(ApplicationUtil.createResponse("Expecting Json data", false));
        }
        RecursoPuesto recursoPuesto  = RecursoPuestoBD.getInstance().updateRecursoPuesto(Json.fromJson(json, RecursoPuesto.class),bibliotecaID,bibliotecaID,id);
        logger.debug("In RecursoPuestoController.update(), recurso de puesto  is: {}",recursoPuesto );
        if (recursoPuesto  == null) {
            return notFound(ApplicationUtil.createResponse("RecursoPuesto not found", false));
        }

        JsonNode jsonObject = Json.toJson(recursoPuesto);
        return ok(ApplicationUtil.createResponse(jsonObject, true));
    }

//SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS

    public Result retrieve(Http.Request request,int bibliotecaID, int puestoID,int id) {
        logger.debug("In RecursoPuestoController.retrieve(), retrieve usuario with id: {}", id);
        RecursoPuesto result = RecursoPuestoBD.getInstance().getRecursoPuesto(bibliotecaID, puestoID, id);
       // if (RecursoPuestoBD.getInstance().getRecursoPuesto(bibliotecaID, puestoID, id) == null) {

           /* if (request.accepts("text/html")) {
                String output = "error";
                try {


                    Configuration cfg = new Configuration(Configuration.VERSION_2_3_30);
                    cfg.setClassLoaderForTemplateLoading(this.getClass().getClassLoader(), "/templates/");
                    cfg.setDefaultEncoding("UTF-8");
                    cfg.setTemplateExceptionHandler(TemplateExceptionHandler.HTML_DEBUG_HANDLER);
                    cfg.setLogTemplateExceptions(false);

                    cfg.setWrapUncheckedExceptions(true);
                    cfg.setFallbackOnNullLoopVariable(false);
                    cfg.setNumberFormat("computer");

                    Template template = cfg.getTemplate("recursoMissing.ftl");
                    StringWriter sw = new StringWriter();
                    Map<String, Object> mapa = new TreeMap<String, Object>();
                    mapa.put("laboratorioID",labID);
                    mapa.put("bancoID",bancoID);
                    mapa.put("recursoID",id);
                    template.process(mapa, sw);
                    output = sw.toString();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return ok(output).as("text/html");

            } else {

                return notFound(ApplicationUtil.createResponse("RecursosBancoDeTrabajo with id:" + id + " not found", false));
            }
        }


        if (request.accepts("text/html")) {
            String output = "error";
            try {


                Configuration cfg = new Configuration(Configuration.VERSION_2_3_30);
                cfg.setClassLoaderForTemplateLoading(this.getClass().getClassLoader(), "/templates/");
                cfg.setDefaultEncoding("UTF-8");
                cfg.setTemplateExceptionHandler(TemplateExceptionHandler.HTML_DEBUG_HANDLER);
                cfg.setLogTemplateExceptions(false);

                cfg.setWrapUncheckedExceptions(true);
                cfg.setFallbackOnNullLoopVariable(false);
                cfg.setNumberFormat("computer");

                Template template = cfg.getTemplate("recurso.ftl");
                StringWriter sw = new StringWriter();
                Map<String, Object> mapa = new TreeMap<String, Object>();
                mapa.put("recurso", result);
                mapa.put("listaDisponibilidadRecursos", result.getListaDisponibilidadRecursos());
                template.process(mapa, sw);
                output = sw.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return ok(output).as("text/html");

        } else { */
            //ObjectMapper mapper = new ObjectMapper();
            JsonNode jsonObjects = Json.toJson(RecursoPuestoBD.getInstance().getRecursoPuesto(bibliotecaID, puestoID, id));
            // JsonNode jsonObjects = mapper.convertValue(RecursoPuestoBD.getInstance().getRecursoPuesto(id),JsonNode.class);

            logger.debug("In RecursoPuestoController.retrieve(), result is: {}", jsonObjects.toString());
            return ok(ApplicationUtil.createResponse(jsonObjects, true));
        //}
    }


    public Result listRecursoPuestos(Http.Request request, int bibliotecaID, int puestoID) {
        Collection<RecursoPuestoShort> result = RecursoPuestoBD.getInstance().getAllRecursoPuesto(bibliotecaID, puestoID);
        logger.debug("In RecursoPuestoController.listRecursoPuestos(), result is: {}", result.toString());
        //ObjectMapper mapper = new ObjectMapper();

       /* if (request.accepts("text/html")) {
            String output = "error";
            try {


                Configuration cfg = new Configuration(Configuration.VERSION_2_3_30);
                cfg.setClassLoaderForTemplateLoading(this.getClass().getClassLoader(), "/templates/");
                cfg.setDefaultEncoding("UTF-8");
                cfg.setTemplateExceptionHandler(TemplateExceptionHandler.HTML_DEBUG_HANDLER);
                cfg.setLogTemplateExceptions(false);

                cfg.setWrapUncheckedExceptions(true);
                cfg.setFallbackOnNullLoopVariable(false);
                cfg.setNumberFormat("computer");

                Template template = cfg.getTemplate("recursos.ftl");
                StringWriter sw = new StringWriter();
                Map<String, Object> mapa = new TreeMap<String, Object>();
                mapa.put("recursos", result);
                mapa.put("labID", labID);
                mapa.put("bancoID", bancoID);
                template.process(mapa, sw);
                output = sw.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return ok(output).as("text/html");

        } else { */
            JsonNode jsonData = Json.toJson(result);
            //JsonNode jsonData = mapper.convertValue(result, JsonNode.class);
            return ok(ApplicationUtil.createResponse(jsonData, true));

       // }
    }

    public Result modify(Http.Request request,int bibliotecaID, int puestoID,int id) throws SQLException, ClassNotFoundException{
        logger.debug("In RecursoPuestoController.modify()");
        JsonNode json = request.body().asJson();
        if (json == null) {
            return badRequest(ApplicationUtil.createResponse("Expecting Json data", false));
        }
        CambioHorario mod = RecursoPuestoBD.getInstance().cambioRecursoPuesto(Json.fromJson(json, CambioHorario.class),bibliotecaID,puestoID,id);

        if (mod == null) {
            return notFound(ApplicationUtil.createResponse("Recurso not found", false));
        }

        JsonNode jsonObject = Json.toJson(mod);
        return ok(ApplicationUtil.createResponse(jsonObject, true));
    }

    public Result delete(Http.Request request,int bibliotecaID, int puestoID,int id) throws SQLException, ClassNotFoundException {
        logger.debug("In RecursoPuestoController.retrieve(), delete recurso de puesto with id: {}",id);
        if (!RecursoPuestoBD.getInstance().deleteRecursoPuesto(bibliotecaID,puestoID,id)) {
            return notFound(ApplicationUtil.createResponse("RecursoPuesto with id:" + id + " not found", false));
        }
        return ok(ApplicationUtil.createResponse("RecursoPuesto with id:" + id + " deleted", true));
    }


}