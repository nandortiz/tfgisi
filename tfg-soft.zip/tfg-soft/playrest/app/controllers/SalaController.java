package controllers;

import entities.Sala;
import entities.SalaShort;
import entities.CambioHorario;
//import freemarker.template.Configuration;
//import freemarker.template.Template;
//import freemarker.template.TemplateExceptionHandler;
import play.mvc.Http;
import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import services.SalaBD;
import utils.ApplicationUtil;

import java.sql.SQLException;
import java.util.Collection;

public class SalaController extends Controller {

    private static final Logger logger = LoggerFactory.getLogger("controller");


    public Result create(Http.Request request,int bibliotecaID) throws SQLException, ClassNotFoundException {
        JsonNode json = request.body().asJson();
        if (json == null) {
            return badRequest(ApplicationUtil.createResponse("Expecting JSON data", false));
        }
        logger.debug("In SalaBD.create(), input is: {}", json.toString());
        Sala sala  = SalaBD.getInstance().addSala(Json.fromJson(json, Sala.class), bibliotecaID);
        JsonNode jsonObject = Json.toJson(sala);
        return created(ApplicationUtil.createResponse(jsonObject, true)).withHeader(LOCATION,sala.getUrl());
    }

    public Result update(Http.Request request,int bibliotecaID,int id) throws SQLException, ClassNotFoundException {
        logger.debug("In SalaController.update()");
        JsonNode json = request.body().asJson();

        if (json == null) {
            return badRequest(ApplicationUtil.createResponse("Expecting Json data", false));
        }
        Sala sala  = SalaBD.getInstance().updateSala(Json.fromJson(json, Sala.class),bibliotecaID,id);
        logger.debug("In PuestoController.update(), puesto  is: {}",sala );
        if (sala  == null) {
            return notFound(ApplicationUtil.createResponse("Sala not found", false));
        }

        JsonNode jsonObject = Json.toJson(sala);
        return ok(ApplicationUtil.createResponse(jsonObject, true));
    }
    public Result modify(Http.Request request, int bibliotecaID, int id) throws SQLException, ClassNotFoundException{
        logger.debug("In SalaController.modify()");
        JsonNode json = request.body().asJson();
        if (json == null) {
            return badRequest(ApplicationUtil.createResponse("Expecting Json data", false));
        }
        CambioHorario cam = SalaBD.getInstance().cambioSala(Json.fromJson(json, CambioHorario.class),bibliotecaID,id);

        if (cam == null) {
            return notFound(ApplicationUtil.createResponse("Sala not found", false));
        }

        JsonNode jsonObject = Json.toJson(cam);
        return ok(ApplicationUtil.createResponse(jsonObject, true));
    }


    public Result retrieve(Http.Request request,int bibliotecaID,int id) {
        logger.debug("In SalaController.retrieve(), retrieve usuario with id: {}", id);
        Sala result = SalaBD.getInstance().getSala(bibliotecaID, id);
      //  if (SalaBD.getInstance().getSala(bibliotecaID, id) == null) {
          /*  if (request.accepts("text/html")) {
                String output = "error";
                try {


                    Configuration cfg = new Configuration(Configuration.VERSION_2_3_30);
                    cfg.setClassLoaderForTemplateLoading(this.getClass().getClassLoader(), "/templates/");
                    cfg.setDefaultEncoding("UTF-8");
                    cfg.setTemplateExceptionHandler(TemplateExceptionHandler.HTML_DEBUG_HANDLER);
                    cfg.setLogTemplateExceptions(false);

                    cfg.setWrapUncheckedExceptions(true);
                    cfg.setFallbackOnNullLoopVariable(false);
                    cfg.setNumberFormat("computer");

                    Template template = cfg.getTemplate("salaMissing.ftl");
                    StringWriter sw = new StringWriter();
                    Map<String, Object> mapa = new TreeMap<String, Object>();
                    mapa.put("bibliotecaID",bibliotecaID);
                    mapa.put("salaID",id);
                    template.process(mapa, sw);
                    output = sw.toString();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return ok(output).as("text/html");

            } else { */

            //    return notFound(ApplicationUtil.createResponse("Sala with id:" + id + " not found", false));
           // }

       // }

     /*   if (request.accepts("text/html")) {
            String output = "error";
            try {


                Configuration cfg = new Configuration(Configuration.VERSION_2_3_30);
                cfg.setClassLoaderForTemplateLoading(this.getClass().getClassLoader(), "/templates/");
                cfg.setDefaultEncoding("UTF-8");
                cfg.setTemplateExceptionHandler(TemplateExceptionHandler.HTML_DEBUG_HANDLER);
                cfg.setLogTemplateExceptions(false);

                cfg.setWrapUncheckedExceptions(true);
                cfg.setFallbackOnNullLoopVariable(false);
                cfg.setNumberFormat("computer");

                Template template = cfg.getTemplate("sala.ftl");
                StringWriter sw = new StringWriter();
                Map<String, Object> mapa = new TreeMap<String, Object>();
                mapa.put("sala", result);
                mapa.put("bibliotecaID",bibliotecaID);
                mapa.put("salaID",id);
                mapa.put("disponibilidadSala", result.getListaDisponibilidadSala());
                mapa.put("listaRecursoSala", result.getListaRecursoSala());
                template.process(mapa, sw);
                output = sw.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return ok(output).as("text/html");

        } else { */
            //ObjectMapper mapper = new ObjectMapper();
            JsonNode jsonObjects = Json.toJson(SalaBD.getInstance().getSala(bibliotecaID, id));
            // JsonNode jsonObjects = mapper.convertValue(SalaBD.getInstance().getSala(id),JsonNode.class);

            logger.debug("In PuestoController.retrieve(), result is: {}", jsonObjects.toString());
            return ok(ApplicationUtil.createResponse(jsonObjects, true));
      //  }
    }

    public Result listSalas(Http.Request request, int bibliotecaID) {
        Collection<SalaShort> result = SalaBD.getInstance().getAllSalas(bibliotecaID);
        logger.debug("In SalaController.listSalas(), result is: {}", result.toString());
        //ObjectMapper mapper = new ObjectMapper();

       /* if (request.accepts("text/html")) {
            String output = "error";
            try {


                Configuration cfg = new Configuration(Configuration.VERSION_2_3_30);
                cfg.setClassLoaderForTemplateLoading(this.getClass().getClassLoader(), "/templates/");
                cfg.setDefaultEncoding("UTF-8");
                cfg.setTemplateExceptionHandler(TemplateExceptionHandler.HTML_DEBUG_HANDLER);
                cfg.setLogTemplateExceptions(false);

                cfg.setWrapUncheckedExceptions(true);
                cfg.setFallbackOnNullLoopVariable(false);
                cfg.setNumberFormat("computer");

                Template template = cfg.getTemplate("salas.ftl");
                StringWriter sw = new StringWriter();
                Map<String, Object> mapa = new TreeMap<String, Object>();
                mapa.put("salas", result);
                mapa.put("bibliotecaID", bibliotecaID);
                template.process(mapa, sw);
                output = sw.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return ok(output).as("text/html");

        } else {*/
            JsonNode jsonData = Json.toJson(result);
            //JsonNode jsonData = mapper.convertValue(result, JsonNode.class);
            return ok(ApplicationUtil.createResponse(jsonData, true));

       // }
    }

    public Result delete(Http.Request request,int bibliotecaID,int id) throws SQLException, ClassNotFoundException {
        logger.debug("In SalaController.delete(), delete sala with id: {}",id);
        if (!SalaBD.getInstance().deleteSala(bibliotecaID,id)) {
            return notFound(ApplicationUtil.createResponse("Sala with id:" + id + " not found", false));
        }
        return ok(ApplicationUtil.createResponse("Sala with id:" + id + " deleted", true));
    }


}
