package entities;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Reserva extends RecursoWeb{
    private Usuario us;
    private BibliotecaShort biblioteca;
        private LocalDateTime DisponibilidadReserva;

    public Reserva(){ super(); }
    public Reserva(int id, String url, Usuario us, BibliotecaShort biblioteca, LocalDateTime DisponibilidadReserva){
        super (id, url);
        this.us =us;
        this.biblioteca=biblioteca;
        this.DisponibilidadReserva=DisponibilidadReserva;

    }

    public Usuario getUs() {
        return us;
    }

    public void setUs(Usuario us) {
        this.us = us;
    }

    public BibliotecaShort getBiblioteca() {
        return biblioteca;
    }

    public void setBiblioteca(BibliotecaShort biblioteca) {
        this.biblioteca = biblioteca;
    }


    public LocalDateTime getDisponibilidadReserva() {
        return DisponibilidadReserva;
    }

    public void setDisponibilidadReserva(LocalDateTime disponibilidadReserva) {
        DisponibilidadReserva = disponibilidadReserva;
    }

}
