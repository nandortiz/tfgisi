package entities;

public class RecursoWeb {

    protected int id;
    protected String url;

    public RecursoWeb(){

    }
    public RecursoWeb(int id, String url){
        this.id = id;
        this.url = url;
    }

    public int getId(){
        return id;

}

    public void setId(int id){
        this.id = id;
}
    public String getUrl(){
        return url;
    }

    public void setUrl(String Url){
        this.url = url;
    }

    @Override
    public String toString(){
        return"RecursoWeb{" +"id= "+id +", URL= '" + url +'}';
    }

}
