package entities;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class RecursoSala extends RecursoWeb{

    private String nombreRecursoSala;
    private String descripcionRecursoSala;
    private int bibliotecaID;
    private int salaID;
    private ArrayList<LocalDateTime> listaDisponibilidadRecursoSala= new ArrayList<>();

    public RecursoSala(){
        super();
    }

    public RecursoSala(int id, String url, String nombreRecursoSala, String descripcionRecursoSala, int bibliotecaID, int salaID ) {
        super(id, url);
        this.nombreRecursoSala=nombreRecursoSala;
        this.descripcionRecursoSala=descripcionRecursoSala;
        this.bibliotecaID=bibliotecaID;
        this.salaID=salaID;

    }

    public String getNombreRecursoSala() {
        return nombreRecursoSala;
    }

    public void setNombreRecursoSala(String nombreRecursoSala) {
        this.nombreRecursoSala = nombreRecursoSala;
    }

    public String getDescripcionRecursoSala() {
        return descripcionRecursoSala;
    }

    public void setDescripcionRecursoSala(String descripcionRecursoSala) {
        this.descripcionRecursoSala = descripcionRecursoSala;
    }


    public int getBibliotecaID() { return bibliotecaID; }

    public void setBibliotecaID(int bibliotecaID) { this.bibliotecaID = bibliotecaID; }

    public int getSalaID() { return salaID; }

    public void setSalaID(int salaID) { this.salaID = salaID; }



    public ArrayList<LocalDateTime> getListaDisponibilidadRecursoSala() {
        return listaDisponibilidadRecursoSala;
    }

    public void setListaDisponibilidadRecursoSala(ArrayList<LocalDateTime> listaDisponibilidadRecursoSala) {
        this.listaDisponibilidadRecursoSala = listaDisponibilidadRecursoSala;
    }

    public void annadirListaDisponibilidadSala(LocalDateTime horario){

        listaDisponibilidadRecursoSala.add(horario);
    }

    @Override
    public String toString() {
        return "Recurso de la sala de grupo {" +
                "id del recurso de la sala='" + id +
                ", nombre del recurso de la sala='" + nombreRecursoSala+ '\'' +
                ", descripción del recurso de la sala='" + descripcionRecursoSala +
                ", lista de disponibilidad de los recursos de la sala='" + listaDisponibilidadRecursoSala +
                '}';
    }



}
