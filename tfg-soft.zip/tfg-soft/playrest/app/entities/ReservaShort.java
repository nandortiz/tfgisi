package entities;

import java.time.LocalDateTime;

public class ReservaShort extends RecursoWeb {
    //private Usuario us;
    private LocalDateTime DisponibilidadReserva;

    public ReservaShort() { super(); }

    public ReservaShort(int id, String url,LocalDateTime DisponibilidadReserva) {
        super(id, url);
        this.DisponibilidadReserva=DisponibilidadReserva;
    }
    /*
        public Usuario getUs() {
            return us;
        }

        public void setUs(Usuario us) {
            this.us = us;
        }
    */
    public LocalDateTime getDisponibilidadReserva() {
        return DisponibilidadReserva;
    }

    public void setDisponibilidadReserva(LocalDateTime disponibilidadReserva) {
        DisponibilidadReserva = disponibilidadReserva;
    }


}