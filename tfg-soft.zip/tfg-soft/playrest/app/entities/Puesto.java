package entities;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Puesto extends RecursoWeb{

    private String descripcionPuesto;
    private int bibliotecaID;
    private ArrayList<LocalDateTime> listaDisponibilidadPuesto= new ArrayList<>();
    private ArrayList<RecursoPuestoShort> listaRecursoPuesto= new ArrayList<>();


    public Puesto(){
        super();
    }

    public Puesto(int id, String url, String descripcionPuesto, int bibliotecaID) {
        super(id, url);
        this.descripcionPuesto=descripcionPuesto;
        this.bibliotecaID=bibliotecaID;
    }


    public String getDescripcionPuesto() {
        return descripcionPuesto;
    }

    public void setDescripcionPuesto(String descripcionPuesto) {
        this.descripcionPuesto = descripcionPuesto;
    }


    public int getBibliotecaID() {
        return bibliotecaID;
    }

    public void setBibliotecaID(int bibliotecaID) {
        this.bibliotecaID = bibliotecaID;
    }
    public ArrayList<RecursoPuestoShort> getListaRecursoPuesto() {
        return listaRecursoPuesto;
    }

    public void setListaRecursoPuesto(ArrayList<RecursoPuestoShort> listaRecursoPuesto) {
        this.listaRecursoPuesto = listaRecursoPuesto;
    }

    public ArrayList<LocalDateTime> getListaDisponibilidadPuesto() {
        return listaDisponibilidadPuesto;
    }

    public void setListaDisponibilidadPuesto(ArrayList<LocalDateTime> listaDisponibilidadPuesto) {
        this.listaDisponibilidadPuesto = listaDisponibilidadPuesto;
    }

    public void annadirListaDisponibilidadPuesto(LocalDateTime horario){

        listaDisponibilidadPuesto.add(horario);
    }

    public void annadirListaRecursoPuesto(RecursoPuestoShort recursoPuesto) {

        listaRecursoPuesto.add(recursoPuesto);
    }

    @Override
    public String toString() {
        return "Puesto de estudio{" +
                "id del puesto de estudio ='" + id +
                ", descripción del puesto de estudio ='" + descripcionPuesto +
                ", lista de recursos del puesto de estudio='" + listaRecursoPuesto +
                ", lista de disponibilidad del puesto de estudio='" + listaDisponibilidadPuesto +
                '}';
    }

}
