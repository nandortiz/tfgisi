package entities;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class RecursoSala extends RecursoWeb{

    private String nombreRecursoPuesto;
    private String descripcionRecursoPuesto;
    private int bibliotecaID;
    private int puestoID;
    private ArrayList<LocalDateTime> listaDisponibilidadRecursoPuesto= new ArrayList<>();

    public RecursoPuesto(){
        super();
    }

    public RecursoPuesto(int id, String url, String nombreRecursoPuesto, String descripcionRecursoPuesto, int bibliotecaID, int puestoID ) {
        super(id, url);
        this.nombreRecursoPuesto=nombreRecursoPuesto;
        this.descripcionRecursoPuesto=descripcionRecursoPuesto;
        this.bibliotecaID=bibliotecaID;
        this.puestoID=puestoID;

    }

    public String getNombreRecursoPuesto() {
        return nombreRecursoPuesto;
    }

    public void setNombreRecursoPuesto(String nombreRecursoPuesto) {
        this.nombreRecursoPuesto = nombreRecursoPuesto;
    }

    public String getDescripcionRecursoPuesto() {
        return descripcionRecursoPuesto;
    }

    public void setDescripcionRecursoPuesto(String descripcionRecursoPuesto) {
        this.descripcionRecursoPuesto = descripcionRecursoPuesto;
    }


    public int getBibliotecaID() { return bibliotecaID; }

    public void setBibliotecaID(int bibliotecaID) { this.bibliotecaID = bibliotecaID; }

    public int getPuestoID() { return puestoID; }

    public void setPuestoID(int puestoID) { this.puestoID = puestoID; }



    public ArrayList<LocalDateTime> getListaDisponibilidadRecursoPuesto() {
        return listaDisponibilidadRecursoPuesto;
    }

    public void setListaDisponibilidadRecursoPuesto(ArrayList<LocalDateTime> listaDisponibilidadRecursoPuesto) {
        this.listaDisponibilidadRecursoPuesto = listaDisponibilidadRecursoPuesto;
    }

    public void annadirListaDisponibilidadRecursoPuesto(LocalDateTime horario){


        listaDisponibilidadRecursoPuesto.add(horario);
    }

    @Override
    public String toString() {
        return "Recurso del puesto de estudio {" +
                "id del recurso del puesto='" + id +
                ", nombre del recurso del puesto='" + nombreRecursoPuesto + '\'' +
                ", descripción del recurso del puesto='" + descripcionRecursoPuesto +
                ", lista de disponibilidad de los recursos del puesto='" + listaDisponibilidadRecursoPuesto +
                '}';
    }



}