package entities;

public enum CambioTipo {
    ADD, REMOVE
}
