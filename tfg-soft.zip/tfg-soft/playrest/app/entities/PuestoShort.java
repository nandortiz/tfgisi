package entities;

public class PuestoShort extends RecursoWeb{
    private String descripcionPuesto;
    private int bibliotecaID;

    public PuestoShort(){
        super();
    }

    public PuestoShort(int id, String url, String descripcionPuesto, int bibliotecaID) {
        super(id, url);
        this.descripcionPuesto=descripcionPuesto;
        this.bibliotecaID=bibliotecaID;
    }

    public String getDescripcionPuesto() {
        return descripcionPuesto;
    }

    public void setDescripcionPuesto(String descripcionPuesto) {
        this.descripcionPuesto = descripcionPuesto;
    }


    public int getBibliotecaID() {
        return bibliotecaID;
    }

    public void setBibliotecaID(int BibliotecaID) {
        this.bibliotecaID = bibliotecaID;
    }
}