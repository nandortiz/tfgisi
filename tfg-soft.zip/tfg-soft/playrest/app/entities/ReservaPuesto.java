package entities;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class ReservaPuesto extends Reserva {

    private PuestoShort puesto;
    private ArrayList<RecursoPuestoShort> listaRecursoPuesto=new ArrayList<>();


    public ReservaPuesto(){ super(); }
    public ReservaPuesto(int id, String url, Usuario us, BibliotecaShort biblioteca, PuestoShort puesto, LocalDateTime DisponibilidadReserva){
        super (id, url, us, biblioteca, DisponibilidadReserva);
        this.puesto=puesto;

    }



    public PuestoShort getPuesto() {
        return puesto;
    }

    public void setPuesto(PuestoShort puesto) {
        this.puesto = puesto;
    }



    public ArrayList<RecursoPuestoShort> getListaRecursoPuesto() {return listaRecursoPuesto; }

    public void setListaRecursoPuesto(ArrayList<RecursoPuestoShort> listaRecursoPuesto) {
        this.listaRecursoPuesto = listaRecursoPuesto;

    }

    public void annadirListaRecursoPuesto(RecursoPuestoShort recursoPuesto){
        listaRecursoPuesto.add(recursoPuesto);
    }


}
