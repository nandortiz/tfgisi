package entities;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Sala extends RecursoWeb{

    private String descripcionSala;
    private int bibliotecaID;
    private ArrayList<LocalDateTime> listaDisponibilidadSala= new ArrayList<>();
    private ArrayList<RecursoSalaShort> listaRecursoSala= new ArrayList<>();


    public Sala(){
        super();
    }

    public Sala(int id, String url, String descripcionSala, int bibliotecaID) {
        super(id, url);
        this.descripcionSala=descripcionSala;
        this.bibliotecaID=bibliotecaID;
    }


    public String getDescripcionSala() {
        return descripcionSala;
    }

    public void setDescripcionSala(String descripcionSala) {
        this.descripcionSala = descripcionSala;
    }


    public int getBibliotecaID() {
        return bibliotecaID;
    }

    public void setBibliotecaID(int bibliotecaID) {
        this.bibliotecaID = bibliotecaID;
    }
    public ArrayList<RecursoSalaShort> getListaRecursoSala() {
        return listaRecursoSala;
    }

    public void setListaRecursoSala(ArrayList<RecursoSalaShort> listaRecursoSala) {
        this.listaRecursoSala = listaRecursoSala;
    }

    public ArrayList<LocalDateTime> getListaDisponibilidadSala() {
        return listaDisponibilidadSala;
    }

    public void setListaDisponibilidadSala(ArrayList<LocalDateTime> listaDisponibilidadSala) {
        this.listaDisponibilidadSala = listaDisponibilidadSala;
    }

    public void annadirListaDisponibilidadSala(LocalDateTime horario){

        listaDisponibilidadSala.add(horario);
    }

    public void annadirListaRecursoSala(RecursoSalaShort recursoSala) {

        listaRecursoSala.add(recursoSala);
    }

    @Override
    public String toString() {
        return "Sala de trabajo en grupo{" +
                "id de la sala grupal ='" + id +
                ", descripción de la sala ='" + descripcionSala +
                ", lista de recursos de la sala='" + listaRecursoSala +
                ", lista de disponibilidad de la sala='" + listaDisponibilidadSala +
                '}';
    }

}
