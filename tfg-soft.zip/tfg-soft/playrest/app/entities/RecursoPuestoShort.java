package entities;

public class RecursoPuestoShort extends RecursoWeb{

    private String nombreRecursoPuesto;
    private String descripcionRecursoPuesto;
    private int bibliotecaID;
    private int puestoID;

    public RecursoPuestoShort(){
        super();
    }

    public RecursoPuestoShort(int id, String url, String nombreRecursoPuesto, String descripcionRecursoPuesto, int bibliotecaID, int puestoID ) {
        super(id, url);
        this.nombreRecursoPuesto=nombreRecursoPuesto;
        this.descripcionRecursoPuesto=descripcionRecursoPuesto;
        this.bibliotecaID=bibliotecaID;
        this.puestoID=puestoID;

    }

    public String getNombreRecursoPuesto() {
        return nombreRecursoPuesto;
    }

    public void setNombreRecursoPuesto(String nombreRecursoPuesto) {
        this.nombreRecursoPuesto = nombreRecursoPuesto;
    }

    public String getDescripcionRecursoPuesto() {
        return descripcionRecursoPuesto;
    }


    public void setDescripcionRecursoPuesto(String descripcionRecursoPuesto) {
        this.descripcionRecursoPuesto = descripcionRecursoPuesto;
    }
    public int getBibliotecaID() { return bibliotecaID; }

    public void setBibliotecaID(int bibliotecaID) { this.bibliotecaID = bibliotecaID; }

    public int getPuestoID() { return puestoID; }

    public void setPuestoID(int puestoID) { this.puestoID = puestoID; }


}