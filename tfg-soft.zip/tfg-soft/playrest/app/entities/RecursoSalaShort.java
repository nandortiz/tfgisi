package entities;

public class RecursoSalaShort extends RecursoWeb{

    private String nombreRecursoSala;
    private String descripcionRecursoSala;
    private int bibliotecaID;
    private int salaID;

    public RecursoSalaShort(){
        super();
    }

    public RecursoSalaShort(int id, String url, String nombreRecursoSala, String descripcionRecursoSala, int bibliotecaID, int salaID ) {
        super(id, url);
        this.nombreRecursoSala=nombreRecursoSala;
        this.descripcionRecursoSala=descripcionRecursoSala;
        this.bibliotecaID=bibliotecaID;
        this.salaID=salaID;

    }

    public String getNombreRecursoSala() {
        return nombreRecursoSala;
    }

    public void setNombreRecursoSala(String nombreRecursoSala) {
        this.nombreRecursoSala = nombreRecursoSala;
    }

    public String getDescripcionRecursoSala() {
        return descripcionRecursoSala;
    }


    public void setDescripcionRecursoSala(String descripcionRecursoSala) {
        this.descripcionRecursoSala = descripcionRecursoSala;
    }
    public int getBibliotecaID() { return bibliotecaID; }

    public void setBibliotecaID(int bibliotecaID) { this.bibliotecaID = bibliotecaID; }

    public int getSalaID() { return salaID; }

    public void setSalaID(int salaID) { this.salaID = salaID; }


}