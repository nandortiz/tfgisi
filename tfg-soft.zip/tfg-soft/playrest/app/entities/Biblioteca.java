package entities;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;

public class Biblioteca extends RecursoWeb{

    private String nombreBiblioteca;
    private String descripcionBiblioteca;
    private ArrayList<LocalDateTime> listaDisponibilidadBiblioteca = new ArrayList<>();
    //horas de apertura y cierre 01/01/2021-10:00 ?¿?¿?¿?¿?¿
    // private ArrayList<Puesto> listaPuesto = new ArrayList<>();
    //  private ArrayList<String> listaPuesto = new ArrayList<>();
    private ArrayList<PuestoShort> listaPuesto = new ArrayList<>();
    private ArrayList<SalaShort> listaSala = new ArrayList<>();

    public Biblioteca(){
        super();

    }



    /*
    public Biblioteca(){

        super(1, "/biblioteca/1");
        this.nombreBiblioteca="nombreBiblioteca";
        this.descripcionBiblioteca="descripcionBiblioteca";
        listaDisponibilidadBiblioteca = new ArrayList<>();
        listaDisponibilidadBiblioteca.add(LocalDateTime.of(2021,05,01,9,30));
        listaDisponibilidadBiblioteca.add(LocalDateTime.of(2021,05,01,10,00 ));
    }
*/

    public Biblioteca(int id, String url, String nombreBiblioteca, String descripcionBiblioteca) {
        super(id, url);
        this.nombreBiblioteca=nombreBiblioteca;
        this.descripcionBiblioteca=descripcionBiblioteca;

    }

    public String getNombreBiblioteca() {
        return nombreBiblioteca;
    }

    public void setNombreBiblioteca(String nombreBiblioteca) {
        this.nombreBiblioteca = nombreBiblioteca;
    }

    public String getDescripcionBiblioteca() {
        return descripcionBiblioteca;
    }

    public void setDescripcionBiblioteca(String descripcionBiblioteca) {
        this.descripcionBiblioteca = descripcionBiblioteca;
    }


    public ArrayList<LocalDateTime> getListaDisponibilidadBiblioteca() {
        return listaDisponibilidadBiblioteca;
    }

    public void setListaDisponibilidadBiblioteca(ArrayList<LocalDateTime> listaDisponibilidadBiblioteca) {
        this.listaDisponibilidadBiblioteca = listaDisponibilidadBiblioteca;
    }

    public ArrayList<PuestoShort> getListaPuesto() {
        return listaPuesto;
    }

    public ArrayList<SalaShort> getListaSala() {
        return listaSala;
    }

    public void setListaPuesto(ArrayList<PuestoShort> listaPuesto) {
        this.listaPuesto = listaPuesto;
    }

    public void setListaSala(ArrayList<SalaShort> listaSala) {
        this.listaSala = listaSala;
    }

    public void annadirListaDisponibilidadBiblioteca(LocalDateTime horario){

        listaDisponibilidadBiblioteca.add(horario);
    }

    public void annadirListaPuesto(PuestoShort puesto){
        listaPuesto.add(puesto);
    }
    public void annadirListaSala(SalaShort sala){
        listaSala.add(sala);
    }
    @Override
    public String toString() {
        return "Biblioteca{" +
                "id de la biblioteca= 'B." + id +
                ", nombre de la biblioteca='" + nombreBiblioteca + '\'' +
                ", descripción de la biblioteca ='" + descripcionBiblioteca +
                ", horarios disponibles='" + listaDisponibilidadBiblioteca+
                '}';
    }
}