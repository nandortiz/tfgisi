package entities;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class ReservaSala extends Reserva{
    private SalaShort sala;
    private ArrayList<RecursoSalaShort> listaRecursoSala=new ArrayList<>();


    public ReservaSala(){ super(); }
    public ReservaSala(int id, String url, Usuario us, BibliotecaShort biblioteca, SalaShort sala, LocalDateTime DisponibilidadReserva){
        super (id, url, us, biblioteca, DisponibilidadReserva);
        this.sala=sala;

    }



    public SalaShort getSala() {
        return sala;
    }

    public void setSala(SalaShort sala) {
        this.sala = sala;
    }



    public ArrayList<RecursoSalaShort> getListaRecursoSala() {return listaRecursoSala; }

    public void setListaRecursoSala(ArrayList<RecursoSalaShort> listaRecursoSala) {
        this.listaRecursoSala = listaRecursoSala;

    }

    public void annadirListaRecursoSala(RecursoSalaShort recursoSala){
        listaRecursoSala.add(recursoSala);
    }


}

